/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Dark mode (default)
        'ah-bg': '#0B0D10',
        'ah-surface': '#161920',
        'ah-card': '#12141A',
        'ah-border': '#262A35',
        'ah-text': '#F3F4F6',
        'ah-muted': '#9CA3AF',
        'ah-accent': '#FF2B44',
      },
    },
  },
  plugins: [],
};
