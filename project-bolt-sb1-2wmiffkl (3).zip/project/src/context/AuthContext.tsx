import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from 'react';
import {
  onAuthStateChanged,
  signOut as firebaseSignOut,
  type User as FirebaseUser,
} from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { fetchProfile, createProfile, updateProfile } from '@/lib/firebase-queries';
import { recalculateBracket } from '@/lib/waf';
import type { Profile, UserRole, Theme, ViewMode, WAFAgeBracket } from '@/lib/types';

type AuthContextValue = {
  user: FirebaseUser | null;
  profile: Profile | null;
  loading: boolean;
  theme: Theme;
  viewMode: ViewMode;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  setLocalProfile: (p: Profile) => void;
  toggleTheme: () => void;
  setViewMode: (mode: ViewMode) => void;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const THEME_KEY = 'armhub_theme';

function loadTheme(): Theme {
  try {
    const stored = localStorage.getItem(THEME_KEY);
    if (stored === 'light' || stored === 'dark') return stored;
  } catch {
    // ignore
  }
  return 'dark'; // Dark mode is the absolute default
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState<Theme>(loadTheme);
  const [viewMode, setViewMode] = useState<ViewMode>('athlete');

  const fetchUserProfile = useCallback(async (uid: string, email: string | null) => {
    try {
      const p = await fetchProfile(uid);
      if (p) {
        // Auto-progression: re-evaluate WAF bracket
        if (p.dateOfBirth) {
          const recalculated = recalculateBracket(p.dateOfBirth);
          if (recalculated && recalculated !== p.wafBracket) {
            const updated = { ...p, wafBracket: recalculated };
            try {
              await updateProfile(uid, { wafBracket: recalculated });
            } catch {
              // non-fatal
            }
            setProfile(updated);
            return;
          }
        }
        setProfile(p);
        // Set view mode based on role
        if (p.role !== 'athlete') {
          setViewMode('organization');
        }
      } else if (email) {
        const newProfile: Profile = {
          uid,
          fullName: email.split('@')[0],
          username: null,
          email,
          role: 'athlete' as UserRole,
          dateOfBirth: null,
          wafBracket: null,
          bio: null,
          weightClass: null,
          primaryArm: 'right',
          country: 'India',
          state: 'West Bengal',
          region: 'North Bengal',
          photoURL: null,
          createdAt: Date.now(),
        };
        await createProfile(newProfile);
        setProfile(newProfile);
      }
    } catch {
      if (email) {
        setProfile({
          uid,
          fullName: email.split('@')[0],
          username: null,
          email,
          role: 'athlete',
          dateOfBirth: null,
          wafBracket: null,
          bio: null,
          weightClass: null,
          primaryArm: 'right',
          country: 'India',
          state: 'West Bengal',
          region: 'North Bengal',
          photoURL: null,
          createdAt: Date.now(),
        });
      }
    }
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        fetchUserProfile(firebaseUser.uid, firebaseUser.email).finally(() => {
          setLoading(false);
        });
      } else {
        setProfile(null);
        setViewMode('athlete');
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, [fetchUserProfile]);

  // Apply theme to document root
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(THEME_KEY, theme);
    } catch {
      // ignore
    }
  }, [theme]);

  const refreshProfile = useCallback(async () => {
    if (user) {
      await fetchUserProfile(user.uid, user.email);
    }
  }, [user, fetchUserProfile]);

  const setLocalProfile = useCallback((p: Profile) => {
    setProfile(p);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((t) => (t === 'dark' ? 'light' : 'dark'));
  }, []);

  const signOut = useCallback(async () => {
    await firebaseSignOut(auth);
    setProfile(null);
    setViewMode('athlete');
  }, []);

  const value: AuthContextValue = {
    user,
    profile,
    loading,
    theme,
    viewMode,
    signOut,
    refreshProfile,
    setLocalProfile,
    toggleTheme,
    setViewMode,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
}
