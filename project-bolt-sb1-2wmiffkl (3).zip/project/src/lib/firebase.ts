import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBsJ9wiWjThu_AKsZ51VQkOQrpfvyb2kwc",
  authDomain: "arm-hub.firebaseapp.com",
  projectId: "arm-hub",
  storageBucket: "arm-hub.firebasestorage.app",
  messagingSenderId: "417390740517",
  appId: "1:417390740517:web:c4f4bd6e35bf95dfe9abcc",
  measurementId: "G-V809J9K17D"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
