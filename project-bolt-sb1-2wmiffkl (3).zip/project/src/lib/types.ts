// ============================================================
// ARM HUB v10.4 — Type Definitions
// ============================================================

// ---- User Roles ----

export type UserRole = 'athlete' | 'admin' | 'federation' | 'association' | 'team' | 'club';

export const ROLE_LABELS: Record<UserRole, string> = {
  athlete: 'Athlete',
  admin: 'Master Admin',
  federation: 'Federation',
  association: 'Association',
  team: 'Team',
  club: 'Club',
};

// ---- Theme ----

export type Theme = 'dark' | 'light';

// ---- Dashboard View Mode (role switching) ----

export type ViewMode = 'athlete' | 'organization';

// ---- WAF Age Brackets ----

export type WAFAgeBracket =
  | 'sub_junior'
  | 'junior_18'
  | 'youth_23'
  | 'senior'
  | 'masters'
  | 'grand_masters'
  | 'senior_grand_masters'
  | 'super_senior_grand_masters';

export const WAF_BRACKET_LABELS: Record<WAFAgeBracket, string> = {
  sub_junior: 'Sub-Junior (14-15)',
  junior_18: 'Junior 18 (Up to 18)',
  youth_23: 'Youth 23 (19-23)',
  senior: 'Senior (Open)',
  masters: 'Masters (40+)',
  grand_masters: 'Grand Masters (50+)',
  senior_grand_masters: 'Senior Grand Masters (60+)',
  super_senior_grand_masters: 'Super Senior Grand Masters (70+)',
};

export const WAF_BRACKET_OPTIONS: { value: WAFAgeBracket; label: string }[] = [
  { value: 'sub_junior', label: 'Sub-Junior (14-15)' },
  { value: 'junior_18', label: 'Junior 18 (Up to 18)' },
  { value: 'youth_23', label: 'Youth 23 (19-23)' },
  { value: 'senior', label: 'Senior (Open)' },
  { value: 'masters', label: 'Masters (40+)' },
  { value: 'grand_masters', label: 'Grand Masters (50+)' },
  { value: 'senior_grand_masters', label: 'Senior Grand Masters (60+)' },
  { value: 'super_senior_grand_masters', label: 'Super Senior Grand Masters (70+)' },
];

// Brackets that are age-restricted (younger categories)
export const YOUTH_BRACKETS: WAFAgeBracket[] = [
  'sub_junior',
  'junior_18',
  'youth_23',
];

// ---- Ranking Levels ----

export type RankingLevel = 'world' | 'national' | 'state' | 'regional';

export const RANKING_LEVEL_LABELS: Record<RankingLevel, string> = {
  world: 'World',
  national: 'National',
  state: 'State',
  regional: 'Regional',
};

// ---- Approval Status ----

export type ApprovalStatus = 'approved' | 'pending' | 'rejected';

export const APPROVAL_STATUS_LABELS: Record<ApprovalStatus, string> = {
  approved: 'Approved',
  pending: 'Pending Review',
  rejected: 'Rejected',
};

// ---- Weight Classes (registration) ----

export const WEIGHT_CLASSES = [
  '60kg', '70kg', '75kg', '80kg', '85kg', '90kg', '100kg+',
] as const;

export type WeightClass = (typeof WEIGHT_CLASSES)[number];

// ---- Ranking weight classes (full list) ----

export const RANKING_WEIGHT_CLASSES = [
  '50kg', '55kg', '60kg', '65kg', '70kg', '75kg',
  '80kg', '85kg', '90kg', '95kg', '100kg', '105kg',
  '110kg', '115kg', '120+kg',
] as const;

// ---- Lift Types ----

export const LIFT_TYPES = [
  'Pronation Hold',
  'Rising Max',
  'Cupping / Wrist Curl',
  'Rolling Thunder',
] as const;

export type LiftType = (typeof LIFT_TYPES)[number];

// ---- Hand ----

export type Hand = 'left' | 'right';

// ---- Geographic options ----

export const COUNTRIES = ['World', 'India'] as const;

export const COUNTRY_STATES: Record<string, string[]> = {
  India: ['All States', 'West Bengal', 'Delhi', 'Maharashtra', 'Karnataka', 'Tamil Nadu'],
};

export const STATE_REGIONS: Record<string, string[]> = {
  'West Bengal': ['All Regions', 'North Bengal', 'South Bengal', 'Kolkata'],
};

export const DISTRICTS: string[] = [
  'Jalpaiguri',
  'Darjeeling',
  'Kalimpong',
  'Alipurduar',
  'Cooch Behar',
  'Malda',
  'Siliguri',
  'Uttar Dinajpur',
  'Dakshin Dinajpur',
];

// ---- Organization ----

export type OrgTier = 'team' | 'club' | 'association' | 'federation';

export const ORG_TIERS: { value: OrgTier; label: string }[] = [
  { value: 'team', label: 'Team' },
  { value: 'club', label: 'Club' },
  { value: 'association', label: 'State Association' },
  { value: 'federation', label: 'National Federation' },
];

export type OrgStatus = 'approved' | 'under_review';

export type Organization = {
  id: string;
  uid: string;
  tier: OrgTier;
  name: string;
  contactName: string | null;
  contactPhone: string | null;
  email: string | null;
  registrationId: string | null;
  address: string | null;
  city: string | null;
  country: string | null;
  state: string | null;
  region: string | null;
  status: OrgStatus;
  docFileName: string | null;
  createdAt: number;
};

// ---- Profile (Firestore document) ----

export type Profile = {
  uid: string;
  fullName: string;
  username: string | null;
  email: string;
  role: UserRole;
  dateOfBirth: string | null; // D/M/YYYY format
  wafBracket: WAFAgeBracket | null;
  bio: string | null;
  weightClass: string | null;
  primaryArm: Hand;
  country: string | null;
  state: string | null;
  region: string | null;
  photoURL: string | null;
  createdAt: number;
};

// ---- Player (ranking entry) ----

export type Player = {
  id: string;
  uid: string | null;
  fullName: string;
  weightClass: string;
  hand: Hand;
  clubName: string | null;
  region: string | null;
  state: string | null;
  country: string | null;
  eloRating: number;
  wins: number;
  losses: number;
  level: RankingLevel;
  approvalStatus: ApprovalStatus;
  createdAt: number;
};

// ---- Lift Record ----

export type LiftRecord = {
  id: string;
  uid: string | null;
  playerName: string;
  weightClass: string;
  liftType: string;
  weightKg: number;
  hand: Hand;
  verified: boolean;
  level: RankingLevel;
  approvalStatus: ApprovalStatus;
  createdAt: number;
};

// ---- Feed Post ----

export type FeedPost = {
  id: string;
  title: string;
  body: string | null;
  authorName: string;
  createdAt: number;
};

// ---- Media Item ----

export type MediaItem = {
  id: string;
  title: string;
  mediaType: 'live' | 'reel' | 'full';
  url: string | null;
  thumbnailUrl: string | null;
  createdAt: number;
};
