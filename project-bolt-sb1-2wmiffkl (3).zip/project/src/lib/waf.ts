import type { WAFAgeBracket } from '@/lib/types';

// ---- Calculate age from DOB string (D/M/YYYY) ----

export function calculateAge(dob: string): number {
  const parts = dob.split('/');
  if (parts.length !== 3) return 0;
  const day = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const year = parseInt(parts[2], 10);
  if (!day || !month || !year) return 0;

  const today = new Date();
  let age = today.getFullYear() - year;
  const monthDiff = today.getMonth() - (month - 1);
  const dayDiff = today.getDate() - day;

  if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) {
    age--;
  }
  return age;
}

// ---- Determine WAF bracket from age ----

export function determineWAFBracket(age: number): WAFAgeBracket {
  if (age <= 13) return 'sub_junior'; // too young, defaults to youngest
  if (age <= 14) return 'sub_junior';
  if (age >= 15 && age <= 18) return 'junior_18';
  if (age > 18 && age <= 23) return 'youth_23';
  if (age <= 39) return 'senior';
  if (age <= 49) return 'masters';
  if (age <= 59) return 'grand_masters';
  if (age <= 69) return 'senior_grand_masters';
  return 'super_senior_grand_masters';
}

// ---- Auto-progression: re-evaluate bracket from DOB ----

export function recalculateBracket(dob: string | null): WAFAgeBracket | null {
  if (!dob) return null;
  const age = calculateAge(dob);
  if (age <= 0) return null;
  return determineWAFBracket(age);
}

// ---- Tournament crossover validation ----

// Youth brackets that are age-restricted (no drop-down for standard seniors)
const RESTRICTED_BRACKETS: WAFAgeBracket[] = [
  'sub_junior',
  'junior_18',
  'youth_23',
];

const MASTERS_BRACKETS: WAFAgeBracket[] = [
  'masters',
  'grand_masters',
  'senior_grand_masters',
  'super_senior_grand_masters',
];

export function canRegisterForBracket(
  userBracket: WAFAgeBracket,
  targetBracket: WAFAgeBracket
): { allowed: boolean; reason?: string } {
  // Senior (Open) is available to everyone
  if (targetBracket === 'senior') {
    return { allowed: true };
  }

  // Masters+ brackets: only those who qualify by age
  if (MASTERS_BRACKETS.includes(targetBracket)) {
    if (MASTERS_BRACKETS.includes(userBracket) || userBracket === 'senior') {
      // Seniors can always go up to masters if they're old enough
      // But if user is in 'senior' bracket they're 24-39, too young for masters
      if (userBracket === 'senior') {
        return {
          allowed: false,
          reason: 'You must be 40+ to register for Masters divisions.',
        };
      }
      return { allowed: true };
    }
    // Youth trying to register for masters
    return {
      allowed: false,
      reason: 'You do not meet the age requirement for this division.',
    };
  }

  // Youth/restricted brackets: only those who qualify by age
  if (RESTRICTED_BRACKETS.includes(targetBracket)) {
    // A standard senior (24-39) cannot drop down to youth brackets
    if (userBracket === 'senior' || MASTERS_BRACKETS.includes(userBracket)) {
      return {
        allowed: false,
        reason: 'Senior athletes cannot register for age-restricted youth brackets.',
      };
    }
    // Must be in the correct age range
    if (userBracket === targetBracket) {
      return { allowed: true };
    }
    // Other youth brackets: check if they're in the right range
    if (RESTRICTED_BRACKETS.includes(userBracket)) {
      return {
        allowed: false,
        reason: 'You can only register for your own age category or the Senior (Open) division.',
      };
    }
  }

  return { allowed: true };
}

// ---- Format DOB for display (D/M/YYYY) ----

export function formatDOB(day: number, month: number, year: number): string {
  return `${day}/${month}/${year}`;
}

// ---- Parse DOB string into parts ----

export function parseDOB(dob: string): { day: number; month: number; year: number } | null {
  const parts = dob.split('/');
  if (parts.length !== 3) return null;
  const day = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const year = parseInt(parts[2], 10);
  if (!day || !month || !year) return null;
  return { day, month, year };
}
