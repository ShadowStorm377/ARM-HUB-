import { supabase } from '@/lib/supabase';
import type {
  Player,
  Club,
  Association,
  LiftRecord,
  FeedPost,
  MediaItem,
  Hand,
  Organization,
  OrgTier,
} from '@/lib/types';

// ---- Players ----

export async function fetchPlayers(
  weightClass?: string,
  hand?: Hand
): Promise<Player[]> {
  let query = supabase
    .from('players')
    .select('*')
    .order('elo_rating', { ascending: false });

  if (weightClass && weightClass !== 'All') {
    query = query.eq('weight_class', weightClass);
  }
  if (hand) {
    query = query.eq('hand', hand);
  }

  const { data, error } = await query.limit(50);
  if (error) throw new Error(error.message);
  return (data || []) as Player[];
}

export async function fetchUserPlayers(userId: string): Promise<Player[]> {
  const { data, error } = await supabase
    .from('players')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []) as Player[];
}

export async function registerPlayer(
  fullName: string,
  weightClass: string,
  hand: Hand,
  clubName?: string,
  region?: string,
  state?: string
): Promise<Player> {
  const { data, error } = await supabase
    .from('players')
    .insert({
      full_name: fullName,
      weight_class: weightClass,
      hand,
      club_name: clubName || null,
      region: region || null,
      state: state || null,
    })
    .select()
    .single();

  if (error) throw new Error(error.message);
  return data as Player;
}

// ---- Clubs ----

export async function fetchClubs(): Promise<Club[]> {
  const { data, error } = await supabase
    .from('clubs')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []) as Club[];
}

export async function registerClub(
  name: string,
  headCoach?: string,
  region?: string
): Promise<Club> {
  const { data, error } = await supabase
    .from('clubs')
    .insert({ name, head_coach: headCoach || null, region: region || null })
    .select()
    .single();

  if (error) throw new Error(error.message);
  return data as Club;
}

// ---- Associations ----

export async function fetchAssociations(): Promise<Association[]> {
  const { data, error } = await supabase
    .from('associations')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []) as Association[];
}

export async function registerAssociation(
  name: string,
  registrationId?: string
): Promise<Association> {
  const { data, error } = await supabase
    .from('associations')
    .insert({ name, registration_id: registrationId || null })
    .select()
    .single();

  if (error) throw new Error(error.message);
  return data as Association;
}

// ---- Organizations ----

export async function registerOrganization(
  tier: OrgTier,
  name: string,
  contactName: string,
  contactPhone: string,
  email: string,
  registrationId?: string,
  address?: string,
  city?: string,
  country?: string,
  state?: string,
  region?: string,
  docFileName?: string
): Promise<Organization> {
  const status = tier === 'team' ? 'approved' : 'under_review';
  const { data, error } = await supabase
    .from('organizations')
    .insert({
      tier,
      name,
      contact_name: contactName || null,
      contact_phone: contactPhone || null,
      email: email || null,
      registration_id: registrationId || null,
      address: address || null,
      city: city || null,
      country: country || 'India',
      state: state || 'West Bengal',
      region: region || 'North Bengal',
      status,
      doc_file_name: docFileName || null,
    })
    .select()
    .single();

  if (error) throw new Error(error.message);
  return data as Organization;
}

export async function fetchUserOrganizations(
  userId: string
): Promise<Organization[]> {
  const { data, error } = await supabase
    .from('organizations')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []) as Organization[];
}

// ---- Lift Records ----

export async function fetchLiftRecords(
  weightClass?: string,
  hand?: Hand
): Promise<LiftRecord[]> {
  let query = supabase
    .from('lift_records')
    .select('*')
    .order('weight_kg', { ascending: false });

  if (weightClass && weightClass !== 'All') {
    query = query.eq('weight_class', weightClass);
  }
  if (hand) {
    query = query.eq('hand', hand);
  }

  const { data, error } = await query.limit(50);
  if (error) throw new Error(error.message);
  return (data || []) as LiftRecord[];
}

export async function submitLiftRecord(
  playerName: string,
  weightClass: string,
  liftType: string,
  weightKg: number,
  hand: Hand
): Promise<LiftRecord> {
  const { data, error } = await supabase
    .from('lift_records')
    .insert({
      player_name: playerName,
      weight_class: weightClass,
      lift_type: liftType,
      weight_kg: weightKg,
      hand,
      verified: false,
    })
    .select()
    .single();

  if (error) throw new Error(error.message);
  return data as LiftRecord;
}

// ---- Feed Posts ----

export async function fetchFeedPosts(): Promise<FeedPost[]> {
  const { data, error } = await supabase
    .from('feed_posts')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []) as FeedPost[];
}

export async function createFeedPost(
  title: string,
  body: string,
  authorName: string
): Promise<FeedPost> {
  const { data, error } = await supabase
    .from('feed_posts')
    .insert({ title, body, author_name: authorName })
    .select()
    .single();

  if (error) throw new Error(error.message);
  return data as FeedPost;
}

// ---- Media Items ----

export async function fetchMediaItems(
  type?: 'live' | 'reel' | 'full'
): Promise<MediaItem[]> {
  let query = supabase
    .from('media_items')
    .select('*')
    .order('created_at', { ascending: false });

  if (type) {
    query = query.eq('media_type', type);
  }

  const { data, error } = await query.limit(50);
  if (error) throw new Error(error.message);
  return (data || []) as MediaItem[];
}
