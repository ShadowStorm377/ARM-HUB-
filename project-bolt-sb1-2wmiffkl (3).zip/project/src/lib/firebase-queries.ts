import {
  collection,
  query,
  orderBy,
  limit,
  where,
  getDocs,
  addDoc,
  doc,
  updateDoc,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type {
  Player,
  LiftRecord,
  FeedPost,
  MediaItem,
  Organization,
  OrgTier,
  RankingLevel,
  ApprovalStatus,
  Hand,
  Profile,
} from '@/lib/types';

function ts(v: unknown): number {
  if (typeof v === 'number') return v;
  if (v && typeof v === 'object' && 'seconds' in v) {
    return (v as { seconds: number }).seconds * 1000;
  }
  return Date.now();
}

// ---- Profile ----

export async function fetchProfile(uid: string): Promise<Profile | null> {
  const q = query(collection(db, 'profiles'), where('uid', '==', uid), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return null;
  const d = snap.docs[0];
  const data = d.data();
  return {
    uid: data.uid ?? uid,
    fullName: data.fullName ?? '',
    username: data.username ?? null,
    email: data.email ?? '',
    role: data.role ?? 'athlete',
    dateOfBirth: data.dateOfBirth ?? null,
    wafBracket: data.wafBracket ?? null,
    bio: data.bio ?? null,
    weightClass: data.weightClass ?? null,
    primaryArm: data.primaryArm ?? 'right',
    country: data.country ?? null,
    state: data.state ?? null,
    region: data.region ?? null,
    photoURL: data.photoURL ?? null,
    createdAt: ts(data.createdAt),
  };
}

export async function createProfile(profile: Profile): Promise<void> {
  await addDoc(collection(db, 'profiles'), {
    ...profile,
    createdAt: serverTimestamp(),
  });
}

export async function updateProfile(
  uid: string,
  updates: Partial<Profile>
): Promise<void> {
  const q = query(collection(db, 'profiles'), where('uid', '==', uid), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return;
  await updateDoc(doc(db, 'profiles', snap.docs[0].id), updates);
}

// ---- Players / Rankings ----

export async function fetchPlayers(
  weightClass: string | null,
  hand: Hand | null,
  level: RankingLevel,
  country: string | null,
  state: string | null,
  region: string | null
): Promise<Player[]> {
  let q = query(
    collection(db, 'players'),
    where('approvalStatus', '==', 'approved'),
    orderBy('eloRating', 'desc'),
    limit(50)
  );

  if (level !== 'world') {
    q = query(
      collection(db, 'players'),
      where('approvalStatus', '==', 'approved'),
      where('level', '==', level),
      orderBy('eloRating', 'desc'),
      limit(50)
    );
  }

  if (weightClass && weightClass !== 'All') {
    q = query(q, where('weightClass', '==', weightClass));
  }
  if (hand) {
    q = query(q, where('hand', '==', hand));
  }
  if (country && country !== 'World') {
    q = query(q, where('country', '==', country));
  }
  if (state && state && state !== 'All States') {
    q = query(q, where('state', '==', state));
  }
  if (region && region !== 'All Regions') {
    q = query(q, where('region', '==', region));
  }

  const snap = await getDocs(q);
  return snap.docs.map((d) => {
    const data = d.data();
    return {
      id: d.id,
      uid: data.uid ?? null,
      fullName: data.fullName ?? '',
      weightClass: data.weightClass ?? '',
      hand: data.hand ?? 'right',
      clubName: data.clubName ?? null,
      region: data.region ?? null,
      state: data.state ?? null,
      country: data.country ?? null,
      eloRating: data.eloRating ?? 0,
      wins: data.wins ?? 0,
      losses: data.losses ?? 0,
      level: data.level ?? 'regional',
      approvalStatus: data.approvalStatus ?? 'approved',
      createdAt: ts(data.createdAt),
    } as Player;
  });
}

export async function fetchUserPlayers(uid: string): Promise<Player[]> {
  const q = query(
    collection(db, 'players'),
    where('uid', '==', uid),
    orderBy('createdAt', 'desc')
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => {
    const data = d.data();
    return {
      id: d.id,
      uid: data.uid ?? null,
      fullName: data.fullName ?? '',
      weightClass: data.weightClass ?? '',
      hand: data.hand ?? 'right',
      clubName: data.clubName ?? null,
      region: data.region ?? null,
      state: data.state ?? null,
      country: data.country ?? null,
      eloRating: data.eloRating ?? 0,
      wins: data.wins ?? 0,
      losses: data.losses ?? 0,
      level: data.level ?? 'regional',
      approvalStatus: data.approvalStatus ?? 'approved',
      createdAt: ts(data.createdAt),
    } as Player;
  });
}

export async function submitPlayerRanking(
  player: Omit<Player, 'id' | 'createdAt'>
): Promise<string> {
  const docRef = await addDoc(collection(db, 'players'), {
    ...player,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

// ---- Lift Records ----

export async function fetchLiftRecords(
  weightClass: string | null,
  hand: Hand | null,
  level: RankingLevel,
  country: string | null,
  state: string | null,
  region: string | null
): Promise<LiftRecord[]> {
  let q = query(
    collection(db, 'lift_records'),
    where('approvalStatus', '==', 'approved'),
    orderBy('weightKg', 'desc'),
    limit(50)
  );

  if (level !== 'world') {
    q = query(
      collection(db, 'lift_records'),
      where('approvalStatus', '==', 'approved'),
      where('level', '==', level),
      orderBy('weightKg', 'desc'),
      limit(50)
    );
  }

  if (weightClass && weightClass !== 'All') {
    q = query(q, where('weightClass', '==', weightClass));
  }
  if (hand) {
    q = query(q, where('hand', '==', hand));
  }
  if (country && country !== 'World') {
    q = query(q, where('country', '==', country));
  }
  if (state && state !== 'All States') {
    q = query(q, where('state', '==', state));
  }
  if (region && region !== 'All Regions') {
    q = query(q, where('region', '==', region));
  }

  const snap = await getDocs(q);
  return snap.docs.map((d) => {
    const data = d.data();
    return {
      id: d.id,
      uid: data.uid ?? null,
      playerName: data.playerName ?? '',
      weightClass: data.weightClass ?? '',
      liftType: data.liftType ?? '',
      weightKg: data.weightKg ?? 0,
      hand: data.hand ?? 'right',
      verified: data.verified ?? false,
      level: data.level ?? 'regional',
      approvalStatus: data.approvalStatus ?? 'approved',
      createdAt: ts(data.createdAt),
    } as LiftRecord;
  });
}

export async function submitLiftRecord(
  lift: Omit<LiftRecord, 'id' | 'createdAt'>
): Promise<string> {
  const docRef = await addDoc(collection(db, 'lift_records'), {
    ...lift,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

// ---- Approval workflow ----

export function determineApprovalLevel(
  hasCountry: boolean,
  hasState: boolean,
  hasRegion: boolean
): { level: RankingLevel; status: ApprovalStatus } {
  if (hasRegion) {
    return { level: 'regional', status: 'approved' };
  }
  if (hasState) {
    return { level: 'state', status: 'pending' };
  }
  if (hasCountry) {
    return { level: 'national', status: 'pending' };
  }
  return { level: 'world', status: 'pending' };
}

export async function approveSubmission(
  collectionName: 'players' | 'lift_records',
  docId: string
): Promise<void> {
  await updateDoc(doc(db, collectionName, docId), {
    approvalStatus: 'approved',
  });
}

export async function rejectSubmission(
  collectionName: 'players' | 'lift_records',
  docId: string
): Promise<void> {
  await updateDoc(doc(db, collectionName, docId), {
    approvalStatus: 'rejected',
  });
}

// ---- Pending submissions (for admin/federation/association dashboard) ----

export async function fetchPendingPlayers(level?: RankingLevel): Promise<Player[]> {
  let q = query(
    collection(db, 'players'),
    where('approvalStatus', '==', 'pending'),
    orderBy('createdAt', 'desc'),
    limit(50)
  );
  if (level) {
    q = query(
      collection(db, 'players'),
      where('approvalStatus', '==', 'pending'),
      where('level', '==', level),
      orderBy('createdAt', 'desc'),
      limit(50)
    );
  }
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Player, 'id'>), createdAt: ts(d.data().createdAt) })) as Player[];
}

export async function fetchPendingLifts(level?: RankingLevel): Promise<LiftRecord[]> {
  let q = query(
    collection(db, 'lift_records'),
    where('approvalStatus', '==', 'pending'),
    orderBy('createdAt', 'desc'),
    limit(50)
  );
  if (level) {
    q = query(
      collection(db, 'lift_records'),
      where('approvalStatus', '==', 'pending'),
      where('level', '==', level),
      orderBy('createdAt', 'desc'),
      limit(50)
    );
  }
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<LiftRecord, 'id'>), createdAt: ts(d.data().createdAt) })) as LiftRecord[];
}

// ---- Organizations ----

export async function registerOrganization(
  tier: OrgTier,
  name: string,
  contactName: string,
  contactPhone: string,
  email: string,
  registrationId?: string,
  address?: string,
  city?: string,
  country?: string,
  state?: string,
  region?: string,
  docFileName?: string
): Promise<string> {
  const status = tier === 'team' ? 'approved' : 'under_review';
  const docRef = await addDoc(collection(db, 'organizations'), {
    tier,
    name,
    contactName: contactName || null,
    contactPhone: contactPhone || null,
    email: email || null,
    registrationId: registrationId || null,
    address: address || null,
    city: city || null,
    country: country || 'India',
    state: state || 'West Bengal',
    region: region || 'North Bengal',
    status,
    docFileName: docFileName || null,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

export async function fetchUserOrganizations(uid: string): Promise<Organization[]> {
  const q = query(
    collection(db, 'organizations'),
    where('uid', '==', uid),
    orderBy('createdAt', 'desc')
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => {
    const data = d.data();
    return {
      id: d.id,
      uid: data.uid ?? uid,
      tier: data.tier ?? 'team',
      name: data.name ?? '',
      contactName: data.contactName ?? null,
      contactPhone: data.contactPhone ?? null,
      email: data.email ?? null,
      registrationId: data.registrationId ?? null,
      address: data.address ?? null,
      city: data.city ?? null,
      country: data.country ?? null,
      state: data.state ?? null,
      region: data.region ?? null,
      status: data.status ?? 'approved',
      docFileName: data.docFileName ?? null,
      createdAt: ts(data.createdAt),
    } as Organization;
  });
}

// ---- Feed Posts ----

export async function fetchFeedPosts(): Promise<FeedPost[]> {
  const q = query(collection(db, 'feed_posts'), orderBy('createdAt', 'desc'), limit(50));
  const snap = await getDocs(q);
  return snap.docs.map((d) => {
    const data = d.data();
    return {
      id: d.id,
      title: data.title ?? '',
      body: data.body ?? null,
      authorName: data.authorName ?? '',
      createdAt: ts(data.createdAt),
    } as FeedPost;
  });
}

export async function createFeedPost(
  title: string,
  body: string,
  authorName: string
): Promise<string> {
  const docRef = await addDoc(collection(db, 'feed_posts'), {
    title,
    body,
    authorName,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

// ---- Media Items ----

export async function fetchMediaItems(
  type?: 'live' | 'reel' | 'full'
): Promise<MediaItem[]> {
  let q = query(collection(db, 'media_items'), orderBy('createdAt', 'desc'), limit(50));
  if (type) {
    q = query(
      collection(db, 'media_items'),
      where('mediaType', '==', type),
      orderBy('createdAt', 'desc'),
      limit(50)
    );
  }
  const snap = await getDocs(q);
  return snap.docs.map((d) => {
    const data = d.data();
    return {
      id: d.id,
      title: data.title ?? '',
      mediaType: data.mediaType ?? 'full',
      url: data.url ?? null,
      thumbnailUrl: data.thumbnailUrl ?? null,
      createdAt: ts(data.createdAt),
    } as MediaItem;
  });
}
