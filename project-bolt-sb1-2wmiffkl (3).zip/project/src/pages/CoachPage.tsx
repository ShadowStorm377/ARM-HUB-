import { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Activity,
  TrendingUp,
  Loader2,
  Check,
  FileVideo,
  Smartphone,
  Cpu,
} from 'lucide-react';

export default function CoachPage() {
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisDone, setAnalysisDone] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Clean up object URL to avoid memory leaks
  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Revoke previous URL
    if (videoUrl) URL.revokeObjectURL(videoUrl);

    const url = URL.createObjectURL(file);
    setVideoUrl(url);
    setFileName(file.name);
    setAnalyzing(true);
    setAnalysisDone(false);

    // Simulate local frame analysis
    setTimeout(() => {
      setAnalyzing(false);
      setAnalysisDone(true);
    }, 2200);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 border-l-2 border-[#FF2B44] pl-2">
        <h2 className="text-lg font-bold text-[#F3F4F6]">Shadow Coach AI</h2>
      </div>
      <p className="-mt-2 text-xs text-[#9CA3AF]">
        AI-powered technique analysis
      </p>

      {/* Zero-cloud badge */}
      <div className="flex items-center gap-2 rounded-xl border border-[#10B981]/30 bg-[#10B981]/10 px-3.5 py-2.5">
        <Smartphone size={16} className="text-[#10B981]" />
        <p className="text-xs font-bold text-[#10B981]">
          Stored on Device - Zero Cloud Storage Used
        </p>
      </div>

      {/* Upload / Video card */}
      <div className="space-y-4 rounded-2xl border border-[#262A35] bg-[#161920] p-4">
        {!videoUrl ? (
          <div className="space-y-4 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-[#FF2B44]/20 bg-[#FF2B44]/10 text-[#FF2B44]">
              <Upload size={24} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#F3F4F6]">
                Upload your sparring video
              </h3>
              <p className="mt-1 text-xs text-[#9CA3AF]">
                Supports .mp4, .mov, .webm - analyzed entirely on your device
              </p>
            </div>

            <label className="block w-full">
              <input
                ref={fileInputRef}
                type="file"
                accept="video/mp4,video/quicktime,video/webm,.mp4,.mov,.webm"
                className="hidden"
                onChange={handleFile}
              />
              <div className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-[#FF2B44] py-3 text-xs font-bold text-white shadow-lg shadow-[#FF2B44]/20 transition hover:bg-[#e8243c]">
                <Upload size={14} />
                Upload Video for Analysis
              </div>
            </label>
          </div>
        ) : (
          <div className="space-y-3">
            {/* Video player */}
            <div className="overflow-hidden rounded-xl border border-[#262A35] bg-black">
              <video
                src={videoUrl}
                controls
                className="h-auto w-full"
              />
            </div>

            {/* File label with badge */}
            <div className="flex items-center justify-between rounded-lg border border-[#262A35] bg-[#0B0D10] px-3 py-2">
              <div className="flex items-center gap-2">
                <FileVideo size={14} className="text-[#9CA3AF]" />
                <span className="text-xs font-medium text-[#F3F4F6]">
                  {fileName}
                </span>
              </div>
              {analysisDone && (
                <span className="flex items-center gap-1 rounded-full bg-[#FF2B44] px-2 py-0.5 text-[9px] font-bold text-white">
                  <Check size={10} />
                  ANALYZED
                </span>
              )}
            </div>

            {/* Analyzing state */}
            {analyzing && (
              <div className="flex items-center justify-center gap-2 rounded-xl border border-[#FF2B44]/30 bg-[#FF2B44]/10 py-4">
                <Loader2 size={18} className="animate-spin text-[#FF2B44]" />
                <span className="text-xs font-bold text-[#FF2B44]">
                  Analyzing Vectors & Pronation...
                </span>
              </div>
            )}

            {/* Upload new */}
            {!analyzing && (
              <label className="block w-full">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="video/mp4,video/quicktime,video/webm,.mp4,.mov,.webm"
                  className="hidden"
                  onChange={handleFile}
                />
                <div className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border border-[#262A35] bg-[#0B0D10] py-2.5 text-xs font-bold text-[#9CA3AF] transition hover:text-[#F3F4F6]">
                  <Upload size={14} />
                  Upload Different Video
                </div>
              </label>
            )}
          </div>
        )}
      </div>

      {/* Local Biomechanics Report */}
      {analysisDone && (
        <div className="space-y-4 rounded-2xl border border-[#262A35] bg-[#161920] p-4">
          {/* Header */}
          <div className="flex items-center gap-2 border-b border-[#262A35] pb-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#FF2B44]/10 text-[#FF2B44]">
              <Cpu size={16} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#F3F4F6]">
                LOCAL BIOMECHANICS REPORT
              </h3>
              <p className="text-[11px] text-[#9CA3AF]">
                Local frame review found a stable arm path suitable for continued
                technical work.
              </p>
            </div>
          </div>

          {/* Telemetry grid */}
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl border border-[#262A35] bg-[#0B0D10] p-3 text-center">
              <div className="text-base font-extrabold text-[#FF2B44]">
                18&deg;
              </div>
              <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">
                Wrist
              </div>
              <div className="mt-0.5 text-[9px] text-[#9CA3AF]/70">
                flexion estimate
              </div>
            </div>
            <div className="rounded-xl border border-[#262A35] bg-[#0B0D10] p-3 text-center">
              <div className="text-base font-extrabold text-[#FF2B44]">
                100&deg;
              </div>
              <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">
                Elbow
              </div>
              <div className="mt-0.5 text-[9px] text-[#9CA3AF]/70">
                elbow angle estimate
              </div>
            </div>
            <div className="rounded-xl border border-[#262A35] bg-[#0B0D10] p-3 text-center">
              <div className="text-base font-extrabold text-[#FF2B44]">
                75%
              </div>
              <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">
                Backpressure
              </div>
              <div className="mt-0.5 text-[9px] text-[#9CA3AF]/70">
                direction estimate
              </div>
            </div>
          </div>

          {/* Coaching bullets */}
          <div className="rounded-xl border border-[#262A35] bg-[#0B0D10] p-3.5">
            <h4 className="mb-2 text-xs font-bold text-[#F3F4F6]">
              Technical Coaching Notes
            </h4>
            <ul className="space-y-1.5 text-xs text-[#9CA3AF]">
              <li className="flex items-start gap-2">
                <span className="text-[#FF2B44]">&bull;</span>
                Keep the wrist stacked behind the knuckles.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#FF2B44]">&bull;</span>
                Drive through the shoulder before opening the elbow.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#FF2B44]">&bull;</span>
                Repeat the same camera angle for more consistent comparisons.
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* Technique cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1 rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#FF2B44]/10 text-[#FF2B44]">
            <Activity size={14} />
          </div>
          <h4 className="pt-1 text-xs font-bold text-[#F3F4F6]">Wrist Vector</h4>
          <p className="text-[10px] leading-tight text-[#9CA3AF]">
            Analyze wrist angle & pressure direction
          </p>
        </div>
        <div className="space-y-1 rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#FF2B44]/10 text-[#FF2B44]">
            <TrendingUp size={14} />
          </div>
          <h4 className="pt-1 text-xs font-bold text-[#F3F4F6]">Force Curve</h4>
          <p className="text-[10px] leading-tight text-[#9CA3AF]">
            Track power output over match duration
          </p>
        </div>
      </div>
    </div>
  );
}
