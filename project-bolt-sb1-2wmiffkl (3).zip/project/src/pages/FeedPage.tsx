import { useState, useEffect, useCallback } from 'react';
import { Activity, Loader2, Plus, AlertCircle, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { fetchFeedPosts, createFeedPost } from '@/lib/firebase-queries';
import { formatRelativeTime } from '@/lib/utils';

type FeedPageProps = {
  onRequireAuth: () => void;
};

export default function FeedPage({ onRequireAuth }: FeedPageProps) {
  const { user, profile } = useAuth();
  const [posts, setPosts] = useState<{ id: string; title: string; body: string | null; authorName: string; createdAt: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchFeedPosts();
      setPosts(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load feed.');
      setPosts([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleCreate = async () => {
    if (!user) {
      onRequireAuth();
      return;
    }
    if (!title.trim()) return;
    setSubmitting(true);
    try {
      await createFeedPost(
        title.trim(),
        body.trim(),
        profile?.fullName || user.email || 'Anonymous'
      );
      setTitle('');
      setBody('');
      setShowCreate(false);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to post.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2 border-l-2 border-[#FF2B44] pl-2">
          <h2 className="text-lg font-bold text-[#F3F4F6]">Association Feed</h2>
        </div>
        <button
          onClick={() => (user ? setShowCreate(true) : onRequireAuth())}
          className="flex items-center gap-1 rounded-lg bg-[#FF2B44] px-3 py-1.5 text-xs font-bold text-white transition hover:bg-[#e8243c]"
        >
          <Plus size={14} />
          Post
        </button>
      </div>
      <p className="-mt-2 text-xs text-[#9CA3AF]">
        Official announcements & updates
      </p>

      {showCreate && (
        <div className="space-y-3 rounded-2xl border border-[#262A35] bg-[#161920] p-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#F3F4F6]">New Announcement</h3>
            <button
              onClick={() => setShowCreate(false)}
              className="text-[#9CA3AF] hover:text-[#F3F4F6]"
            >
              <X size={16} />
            </button>
          </div>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Title..."
            className="w-full rounded-xl border border-[#262A35] bg-[#0B0D10] px-3.5 py-2.5 text-sm text-[#F3F4F6] outline-none focus:border-[#FF2B44]"
          />
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Details..."
            rows={3}
            className="w-full resize-none rounded-xl border border-[#262A35] bg-[#0B0D10] px-3.5 py-2.5 text-sm text-[#F3F4F6] outline-none focus:border-[#FF2B44]"
          />
          <button
            onClick={handleCreate}
            disabled={submitting || !title.trim()}
            className="w-full rounded-xl bg-[#FF2B44] py-2.5 text-xs font-bold text-white transition hover:bg-[#e8243c] disabled:opacity-50"
          >
            {submitting ? 'Posting...' : 'Publish'}
          </button>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-[#FF2B44]" />
        </div>
      ) : error ? (
        <div className="flex items-center gap-2 rounded-xl border border-[#FF2B44]/40 bg-[#FF2B44]/10 p-4 text-xs text-[#FF2B44]">
          <AlertCircle size={16} />
          {error}
        </div>
      ) : posts.length === 0 ? (
        <div className="space-y-3 rounded-2xl border border-[#262A35] bg-[#161920] p-6 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#FF2B44]/10 text-[#FF2B44]">
            <Activity size={24} />
          </div>
          <h3 className="text-sm font-bold text-[#F3F4F6]">No announcements yet</h3>
          <p className="text-xs text-[#9CA3AF]">
            Be the first to post an update for the association.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {posts.map((post) => (
            <div
              key={post.id}
              className="rounded-2xl border border-[#262A35] bg-[#161920] p-4"
            >
              <div className="flex items-center gap-2 text-[10px] text-[#9CA3AF]">
                <span className="font-semibold text-[#FF2B44]">
                  {post.authorName}
                </span>
                <span>- {formatRelativeTime(post.createdAt)}</span>
              </div>
              <h3 className="mt-2 text-sm font-bold text-[#F3F4F6]">{post.title}</h3>
              {post.body && (
                <p className="mt-1 text-xs leading-relaxed text-[#9CA3AF]">
                  {post.body}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
