import { useState, useEffect, useCallback } from 'react';
import { Loader2, AlertCircle, Video, Play } from 'lucide-react';
import { fetchMediaItems } from '@/lib/firebase-queries';
import { formatRelativeTime } from '@/lib/utils';

export default function MediaPage() {
  const [subTab, setSubTab] = useState<'live' | 'reel' | 'full'>('live');
  const [items, setItems] = useState<{ id: string; title: string; mediaType: 'live' | 'reel' | 'full'; url: string | null; thumbnailUrl: string | null; createdAt: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchMediaItems(subTab);
      setItems(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load media.');
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, [subTab]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 border-l-2 border-[#FF2B44] pl-2">
        <h2 className="text-lg font-bold text-[#F3F4F6]">Live & Media</h2>
      </div>
      <p className="-mt-2 text-xs text-[#9CA3AF]">
        Tournament streams, reels & full videos
      </p>

      <div className="grid grid-cols-3 gap-2 rounded-xl border border-[#262A35] bg-[#161920] p-1">
        {(['live', 'reel', 'full'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setSubTab(t)}
            className={`rounded-lg py-2 text-[11px] font-bold transition-all ${
              subTab === t
                ? 'bg-[#FF2B44] text-white'
                : 'text-[#9CA3AF] hover:text-[#F3F4F6]'
            }`}
          >
            {t === 'live' ? 'LIVE STREAM' : t === 'reel' ? 'REELS' : 'FULL VIDEOS'}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-[#FF2B44]" />
        </div>
      ) : error ? (
        <div className="flex items-center gap-2 rounded-xl border border-[#FF2B44]/40 bg-[#FF2B44]/10 p-4 text-xs text-[#FF2B44]">
          <AlertCircle size={16} />
          {error}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-2xl border border-[#262A35] bg-[#161920] p-12 text-center text-xs text-[#9CA3AF]">
          {subTab === 'live'
            ? 'No live streams right now.'
            : subTab === 'reel'
            ? 'No reels uploaded yet.'
            : 'No full videos available yet.'}
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item) => (
            <div
              key={item.id}
              className="overflow-hidden rounded-2xl border border-[#262A35] bg-[#161920]"
            >
              <div className="relative flex aspect-video items-center justify-center bg-[#0B0D10]">
                {item.thumbnailUrl ? (
                  <img
                    src={item.thumbnailUrl}
                    alt={item.title}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <Video size={32} className="text-[#262A35]" />
                )}
                {subTab === 'live' && (
                  <div className="absolute top-2 left-2 flex items-center gap-1 rounded-full bg-[#FF2B44] px-2 py-0.5 text-[9px] font-bold text-white">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
                    LIVE
                  </div>
                )}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FF2B44]/80 backdrop-blur">
                    <Play size={18} className="ml-0.5 text-white" fill="white" />
                  </div>
                </div>
              </div>
              <div className="p-3">
                <h4 className="text-xs font-bold text-[#F3F4F6]">{item.title}</h4>
                <p className="mt-0.5 text-[10px] text-[#9CA3AF]">
                  {formatRelativeTime(item.createdAt)}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
