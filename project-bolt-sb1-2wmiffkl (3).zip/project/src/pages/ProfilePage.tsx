import { useState, useEffect, useCallback } from 'react';
import {
  Loader2,
  ShieldCheck,
  Trophy,
  TrendingUp,
  Calendar,
  Zap,
  Mail,
  Pencil,
  X,
  Check,
  Dumbbell,
  Building2,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { fetchUserPlayers, fetchUserOrganizations, updateProfile } from '@/lib/firebase-queries';
import {
  ROLE_LABELS,
  WAF_BRACKET_LABELS,
  type Player,
  type UserRole,
  type Organization,
  type ViewMode,
} from '@/lib/types';
import { calculateAge, formatDOB } from '@/lib/waf';
import { formatRelativeTime } from '@/lib/utils';

type ProfilePageProps = {
  onRequireAuth: () => void;
};

export default function ProfilePage({ onRequireAuth }: ProfilePageProps) {
  const { user, profile, loading: authLoading, viewMode, setViewMode, refreshProfile } = useAuth();
  const [players, setPlayers] = useState<Player[]>([]);
  const [orgs, setOrgs] = useState<Organization[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState('');
  const [bio, setBio] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!user?.uid) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const [playerData, orgData] = await Promise.all([
        fetchUserPlayers(user.uid).catch(() => [] as Player[]),
        fetchUserOrganizations(user.uid).catch(() => [] as Organization[]),
      ]);
      setPlayers(playerData);
      setOrgs(orgData);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, [user?.uid]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (profile) {
      setFullName(profile.fullName);
      setBio(profile.bio || '');
    }
  }, [profile]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    setError(null);
    try {
      await updateProfile(user.uid, {
        fullName: fullName.trim(),
        bio: bio.trim() || null,
      });
      await refreshProfile();
      setEditing(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save.');
    } finally {
      setSaving(false);
    }
  };

  if (authLoading) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-[#FF2B44]" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="space-y-4">
        <div className="flex items-center space-x-2 border-l-2 border-[#FF2B44] pl-2">
          <h2 className="text-lg font-bold text-[#F3F4F6]">Profile</h2>
        </div>
        <div className="rounded-2xl border border-[#262A35] bg-[#161920] p-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-[#FF2B44]/10 text-[#FF2B44]">
            <Dumbbell size={28} />
          </div>
          <h3 className="text-base font-bold text-[#F3F4F6]">
            You're not logged in
          </h3>
          <p className="mt-2 text-xs text-[#9CA3AF]">
            Log in or sign up to view your athlete dashboard, track stats, and
            register for tournaments.
          </p>
          <div className="mt-5 flex justify-center gap-2">
            <button
              onClick={onRequireAuth}
              className="rounded-xl bg-[#FF2B44] px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-[#FF2B44]/20 transition hover:bg-[#e8243c]"
            >
              Sign Up
            </button>
            <button
              onClick={() => onRequireAuth()}
              className="rounded-xl border border-[#262A35] bg-[#161920] px-5 py-2.5 text-xs font-bold text-[#9CA3AF] transition hover:text-[#F3F4F6]"
            >
              Log In
            </button>
          </div>
        </div>
      </div>
    );
  }

  const userRole: UserRole = (profile?.role as UserRole) || 'athlete';
  const hasOrgRole = userRole !== 'athlete';

  const topPlayer = players[0];
  const totalWins = players.reduce((s, p) => s + p.wins, 0);
  const totalLosses = players.reduce((s, p) => s + p.losses, 0);
  const totalMatches = totalWins + totalLosses;
  const winRate = totalMatches > 0 ? Math.round((totalWins / totalMatches) * 100) : 0;
  const totalPoints = topPlayer?.eloRating || 0;

  const wafLabel = profile?.wafBracket ? WAF_BRACKET_LABELS[profile.wafBracket] : 'Not set';
  const ageDisplay = profile?.dateOfBirth ? calculateAge(profile.dateOfBirth) : null;

  const categoryLabel = [
    wafLabel,
    profile?.weightClass,
    profile?.primaryArm === 'left' ? 'Left' : 'Right',
  ].filter(Boolean).join(' - ');

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 border-l-2 border-[#FF2B44] pl-2">
        <h2 className="text-lg font-bold text-[#F3F4F6]">Profile</h2>
        {hasOrgRole && (
          <div className="ml-auto flex gap-1 rounded-lg border border-[#262A35] bg-[#161920] p-0.5">
            <button
              onClick={() => setViewMode('athlete' as ViewMode)}
              className={`rounded-md px-2.5 py-1 text-[10px] font-bold transition ${
                viewMode === 'athlete' ? 'bg-[#FF2B44] text-white' : 'text-[#9CA3AF]'
              }`}
            >
              Athlete
            </button>
            <button
              onClick={() => setViewMode('organization' as ViewMode)}
              className={`rounded-md px-2.5 py-1 text-[10px] font-bold transition ${
                viewMode === 'organization' ? 'bg-[#FF2B44] text-white' : 'text-[#9CA3AF]'
              }`}
            >
              Org
            </button>
          </div>
        )}
      </div>
      <p className="-mt-2 text-xs text-[#9CA3AF]">
        {viewMode === 'organization' ? 'Organization dashboard' : 'Your athlete dashboard'}
      </p>

      {/* Organization dashboard view */}
      {viewMode === 'organization' && hasOrgRole ? (
        <div className="space-y-4">
          <div className="space-y-4 rounded-2xl border border-[#262A35] bg-[#161920] p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl border-2 border-[#FF2B44] bg-[#0B0D10]">
                <Building2 size={24} className="text-[#FF2B44]" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-[#F3F4F6]">
                  {profile?.fullName || 'Organization'}
                </h3>
                <p className="text-[11px] text-[#9CA3AF]">{ROLE_LABELS[userRole]}</p>
                <span className="mt-0.5 inline-block rounded-full bg-[#FF2B44]/15 px-2 py-0.5 text-[10px] font-bold text-[#FF2B44]">
                  {wafLabel}
                </span>
              </div>
            </div>

            {/* Org stats */}
            <div className="grid grid-cols-3 gap-2 rounded-xl border border-[#262A35] bg-[#0B0D10] p-3 text-center">
              <div>
                <div className="text-base font-extrabold text-[#FF2B44]">{orgs.length}</div>
                <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">Entities</div>
              </div>
              <div>
                <div className="text-base font-extrabold text-[#10B981]">
                  {orgs.filter((o) => o.status === 'approved').length}
                </div>
                <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">Active</div>
              </div>
              <div>
                <div className="text-base font-extrabold text-[#FF2B44]">
                  {orgs.filter((o) => o.status === 'under_review').length}
                </div>
                <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">Pending</div>
              </div>
            </div>

            <div className="flex items-center gap-3 text-[10px] text-[#9CA3AF]">
              <span className="flex items-center gap-1">
                <Mail size={12} />
                {user.email}
              </span>
            </div>
          </div>

          {/* Org list */}
          {orgs.length > 0 && (
            <div className="space-y-3">
              <h3 className="flex items-center gap-2 text-sm font-bold text-[#F3F4F6]">
                <Building2 size={16} className="text-[#FF2B44]" />
                Organizations
              </h3>
              {orgs.map((org) => (
                <div key={org.id} className="rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-[#F3F4F6]">{org.name}</h4>
                      <p className="text-[10px] text-[#9CA3AF] capitalize">
                        {org.tier} - {org.region}, {org.state}
                      </p>
                    </div>
                    <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${
                      org.status === 'approved' ? 'bg-[#10B981]/15 text-[#10B981]' : 'bg-[#FF2B44]/15 text-[#FF2B44]'
                    }`}>
                      {org.status === 'approved' ? 'ACTIVE' : 'PENDING'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Athlete card */}
          <div className="space-y-4 rounded-2xl border border-[#262A35] bg-[#161920] p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-[#FF2B44] bg-[#0B0D10] text-base font-black text-[#F3F4F6]">
                  {(profile?.fullName || user.email || '?').charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-[#F3F4F6]">
                    {profile?.fullName || 'Anonymous'}
                  </h3>
                  {profile?.username && (
                    <p className="text-[11px] text-[#9CA3AF]">@{profile.username}</p>
                  )}
                  <p className="text-[11px] text-[#9CA3AF]">
                    {topPlayer?.clubName || 'No Club Registered'}
                  </p>
                  {categoryLabel && (
                    <span className="mt-0.5 inline-block text-[10px] font-semibold text-[#9CA3AF]">
                      {categoryLabel}
                    </span>
                  )}
                </div>
              </div>
              {!editing && (
                <button
                  onClick={() => setEditing(true)}
                  className="flex items-center gap-1 rounded-lg border border-[#262A35] px-2.5 py-1.5 text-[11px] font-bold text-[#9CA3AF] transition hover:text-[#F3F4F6]"
                >
                  <Pencil size={12} />
                  Edit
                </button>
              )}
            </div>

            {/* Role badge */}
            {userRole !== 'athlete' && (
              <div className="flex items-center gap-2 rounded-lg border border-[#FF2B44]/30 bg-[#FF2B44]/10 px-3 py-2 text-[11px] font-bold text-[#FF2B44]">
                <ShieldCheck size={14} />
                {ROLE_LABELS[userRole]}
              </div>
            )}

            {/* WAF bracket badge */}
            {profile?.wafBracket && (
              <div className="flex items-center justify-between rounded-lg border border-[#10B981]/30 bg-[#10B981]/10 px-3 py-2">
                <div className="flex items-center gap-2">
                  <Calendar size={14} className="text-[#10B981]" />
                  <span className="text-[11px] font-bold text-[#10B981]">
                    {WAF_BRACKET_LABELS[profile.wafBracket]}
                  </span>
                </div>
                {ageDisplay !== null && (
                  <span className="text-[10px] text-[#9CA3AF]">Age {ageDisplay}</span>
                )}
              </div>
            )}

            {/* Editing form */}
            {editing ? (
              <div className="space-y-3">
                <div>
                  <label className="mb-1 block text-xs font-bold text-[#9CA3AF]">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full rounded-xl border border-[#262A35] bg-[#0B0D10] px-3.5 py-2.5 text-sm text-[#F3F4F6] outline-none focus:border-[#FF2B44]"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-bold text-[#9CA3AF]">
                    Bio
                  </label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    rows={2}
                    placeholder="Tell about yourself..."
                    className="w-full resize-none rounded-xl border border-[#262A35] bg-[#0B0D10] px-3.5 py-2.5 text-sm text-[#F3F4F6] outline-none focus:border-[#FF2B44]"
                  />
                </div>
                {profile?.dateOfBirth && (
                  <div className="rounded-lg border border-[#262A35] bg-[#0B0D10] px-3 py-2 text-[11px] text-[#9CA3AF]">
                    DOB: {profile.dateOfBirth} - To change your DOB, use the Edit Profile option in the menu.
                  </div>
                )}
                {error && <p className="text-xs font-medium text-[#FF2B44]">{error}</p>}
                <div className="flex gap-2">
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="flex items-center gap-1.5 rounded-lg bg-[#FF2B44] px-4 py-2 text-xs font-bold text-white transition hover:bg-[#e8243c] disabled:opacity-60"
                  >
                    {saving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                    Save
                  </button>
                  <button
                    onClick={() => { setEditing(false); setError(null); }}
                    className="flex items-center gap-1.5 rounded-lg border border-[#262A35] px-4 py-2 text-xs font-bold text-[#9CA3AF] transition hover:text-[#F3F4F6]"
                  >
                    <X size={14} />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Stats */}
                <div className="grid grid-cols-4 gap-2 rounded-xl border border-[#262A35] bg-[#0B0D10] p-3 text-center">
                  <div>
                    <div className="text-base font-extrabold text-[#FF2B44]">{totalPoints}</div>
                    <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">Points</div>
                  </div>
                  <div>
                    <div className="text-base font-extrabold text-[#FF2B44]">{totalMatches}</div>
                    <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">Matches</div>
                  </div>
                  <div>
                    <div className="text-base font-extrabold text-[#10B981]">{totalWins}</div>
                    <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">Wins</div>
                  </div>
                  <div>
                    <div className="text-base font-extrabold text-[#FF2B44]">{totalLosses}</div>
                    <div className="text-[9px] font-bold uppercase text-[#9CA3AF]">Losses</div>
                  </div>
                </div>

                {profile?.bio && (
                  <p className="text-xs leading-relaxed text-[#9CA3AF]">{profile.bio}</p>
                )}
                <div className="flex flex-wrap items-center gap-3 text-[10px] text-[#9CA3AF]">
                  <span className="flex items-center gap-1">
                    <Mail size={12} />
                    {user.email}
                  </span>
                  {profile?.state && (
                    <span className="flex items-center gap-1">
                      <ShieldCheck size={12} className="text-[#10B981]" />
                      {profile.state}
                    </span>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Performance cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
              <div className="flex items-center gap-1 text-[10px] font-bold uppercase text-[#FF2B44]">
                <Trophy size={13} />
                <span>State Rank</span>
              </div>
              <div className="mt-1 text-sm font-extrabold text-[#F3F4F6]">
                {totalMatches > 0 ? `#${players.length > 0 ? '1' : '-'}` : 'Unranked'}
              </div>
              <div className="text-[10px] text-[#9CA3AF]">
                {topPlayer ? `${topPlayer.hand === 'left' ? 'Left' : 'Right'} - ${topPlayer.weightClass}` : 'Not ranked'}
              </div>
            </div>
            <div className="rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
              <div className="flex items-center gap-1 text-[10px] font-bold uppercase text-[#FF2B44]">
                <TrendingUp size={13} />
                <span>Win Rate</span>
              </div>
              <div className="mt-1 text-sm font-extrabold text-[#F3F4F6]">{winRate}%</div>
              <div className="text-[10px] text-[#9CA3AF]">{totalMatches} matches</div>
            </div>
            <div className="rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
              <div className="flex items-center gap-1 text-[10px] font-bold uppercase text-[#FF2B44]">
                <Calendar size={13} />
                <span>Joined</span>
              </div>
              <div className="mt-1 text-sm font-extrabold text-[#F3F4F6]">
                {profile ? formatRelativeTime(profile.createdAt) : 'Recently'}
              </div>
              <div className="text-[10px] text-[#9CA3AF]">{wafLabel}</div>
            </div>
            <div className="rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
              <div className="flex items-center gap-1 text-[10px] font-bold uppercase text-[#FF2B44]">
                <Zap size={13} />
                <span>Registrations</span>
              </div>
              <div className="mt-1 text-sm font-extrabold text-[#F3F4F6]">{players.length}</div>
              <div className="text-[10px] text-[#9CA3AF]">Active profiles</div>
            </div>
          </div>

          {/* My registrations */}
          {loading ? null : players.length > 0 ? (
            <div className="space-y-3">
              <h3 className="flex items-center gap-2 text-sm font-bold text-[#F3F4F6]">
                <Dumbbell size={16} className="text-[#FF2B44]" />
                My Registrations
              </h3>
              {players.map((p) => (
                <div key={p.id} className="rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-[#F3F4F6]">{p.fullName}</h4>
                      <p className="text-[10px] text-[#9CA3AF]">
                        {p.weightClass} - {p.hand === 'left' ? 'Left' : 'Right'} Hand
                        {p.clubName && ` - ${p.clubName}`}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-[#FF2B44]">{p.eloRating} pts</div>
                      <div className="text-[10px] text-[#9CA3AF]">{p.wins}W / {p.losses}L</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
