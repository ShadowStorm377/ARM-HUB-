import { useState, useEffect, useCallback } from 'react';
import {
  Loader2,
  TrendingUp,
  AlertCircle,
  Globe,
  ChevronDown,
  Check,
  Clock,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import {
  fetchPlayers,
  fetchLiftRecords,
  determineApprovalLevel,
} from '@/lib/firebase-queries';
import { useAuth } from '@/context/AuthContext';
import {
  RANKING_WEIGHT_CLASSES,
  COUNTRIES,
  COUNTRY_STATES,
  STATE_REGIONS,
  ROLE_LABELS,
  type Player,
  type LiftRecord,
  type Hand,
  type RankingLevel,
  type UserRole,
} from '@/lib/types';

// ---- RBAC: which roles can edit which ranking levels ----

function canEditRanking(role: UserRole, level: RankingLevel): boolean {
  if (role === 'admin') return true;
  if (role === 'federation' && level === 'national') return true;
  if (role === 'association' && level === 'state') return true;
  return false;
}

function getEditableLevels(role: UserRole): RankingLevel[] {
  if (role === 'admin') return ['world', 'national', 'state', 'regional'];
  if (role === 'federation') return ['national'];
  if (role === 'association') return ['state'];
  return [];
}

export default function RankingsPage() {
  const { profile } = useAuth();
  const userRole: UserRole = (profile?.role as UserRole) || 'athlete';

  const [rankingType, setRankingType] = useState<'player' | 'lift'>('player');
  const [hand, setHand] = useState<Hand>('left');
  const [selectedWeight, setSelectedWeight] = useState('70kg');

  // Cascading geographic filters
  const [geoLevel, setGeoLevel] = useState<RankingLevel>('world');
  const [selectedCountry, setSelectedCountry] = useState('World');
  const [selectedState, setSelectedState] = useState('All States');
  const [selectedRegion, setSelectedRegion] = useState('All Regions');

  const [players, setPlayers] = useState<Player[]>([]);
  const [lifts, setLifts] = useState<LiftRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Determine geographic level from selections
  const computeLevel = (): RankingLevel => {
    if (selectedCountry === 'World') return 'world';
    if (selectedState === 'All States') return 'national';
    if (selectedRegion === 'All Regions') return 'state';
    return 'regional';
  };

  const availableStates =
    selectedCountry !== 'World' && COUNTRY_STATES[selectedCountry]
      ? COUNTRY_STATES[selectedCountry]
      : ['All States'];

  const availableRegions =
    selectedState !== 'All States' && STATE_REGIONS[selectedState]
      ? STATE_REGIONS[selectedState]
      : ['All Regions'];

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const level = computeLevel();
    setGeoLevel(level);
    try {
      const [playerData, liftData] = await Promise.all([
        fetchPlayers(
          selectedWeight,
          hand,
          level,
          selectedCountry,
          selectedState,
          selectedRegion
        ),
        fetchLiftRecords(
          selectedWeight,
          hand,
          level,
          selectedCountry,
          selectedState,
          selectedRegion
        ),
      ]);
      setPlayers(playerData);
      setLifts(liftData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load rankings.');
      setPlayers([]);
      setLifts([]);
    } finally {
      setLoading(false);
    }
  }, [selectedWeight, hand, selectedCountry, selectedState, selectedRegion]);

  useEffect(() => {
    load();
  }, [load]);

  const editableLevels = getEditableLevels(userRole);
  const canEditCurrent = canEditRanking(userRole, geoLevel);

  const levelLabel =
    geoLevel === 'world'
      ? 'Global Standings'
      : geoLevel === 'national'
      ? `${selectedCountry} National Rankings`
      : geoLevel === 'state'
      ? `${selectedState} State Rankings`
      : `${selectedRegion} Regional Rankings`;

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 border-l-2 border-[#FF2B44] pl-2">
        <h2 className="text-lg font-bold text-[#F3F4F6]">Rankings</h2>
      </div>
      <p className="-mt-2 text-xs text-[#9CA3AF]">
        Live athlete & lift standings
      </p>

      {/* Player vs Lift selector */}
      <div className="grid grid-cols-2 gap-2 rounded-xl border border-[#262A35] bg-[#161920] p-1">
        <button
          onClick={() => setRankingType('player')}
          className={`rounded-lg py-2 text-xs font-bold transition-all ${
            rankingType === 'player'
              ? 'bg-[#FF2B44] text-white shadow-md shadow-[#FF2B44]/20'
              : 'text-[#9CA3AF] hover:text-[#F3F4F6]'
          }`}
        >
          Player Rankings
        </button>
        <button
          onClick={() => setRankingType('lift')}
          className={`rounded-lg py-2 text-xs font-bold transition-all ${
            rankingType === 'lift'
              ? 'bg-[#FF2B44] text-white shadow-md shadow-[#FF2B44]/20'
              : 'text-[#9CA3AF] hover:text-[#F3F4F6]'
          }`}
        >
          Lift Rankings
        </button>
      </div>

      {/* Left/Right Hand */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setHand('left')}
          className={`rounded-xl border py-2 text-xs font-bold transition-all ${
            hand === 'left'
              ? 'border-[#FF2B44] bg-[#FF2B44] text-white'
              : 'border-[#262A35] bg-[#161920] text-[#9CA3AF]'
          }`}
        >
          Left Hand
        </button>
        <button
          onClick={() => setHand('right')}
          className={`rounded-xl border py-2 text-xs font-bold transition-all ${
            hand === 'right'
              ? 'border-[#FF2B44] bg-[#FF2B44] text-white'
              : 'border-[#262A35] bg-[#161920] text-[#9CA3AF]'
          }`}
        >
          Right Hand
        </button>
      </div>

      {/* Weight classes */}
      <div className="scrollbar-none flex gap-2 overflow-x-auto py-1">
        {RANKING_WEIGHT_CLASSES.map((w) => (
          <button
            key={w}
            onClick={() => setSelectedWeight(w)}
            className={`whitespace-nowrap rounded-full border px-3.5 py-1.5 text-xs font-bold transition-all ${
              selectedWeight === w
                ? 'border-[#FF2B44] bg-[#FF2B44] text-white shadow-lg shadow-[#FF2B44]/30'
                : 'border-[#262A35] bg-[#161920] text-[#9CA3AF] hover:border-[#9CA3AF]'
            }`}
          >
            {w}
          </button>
        ))}
      </div>

      {/* Cascading Geographic Filter */}
      <div className="space-y-3 rounded-xl border border-[#262A35] bg-[#161920] p-4">
        <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
          <span className="flex items-center gap-1.5 text-[#FF2B44]">
            <Globe size={13} /> GEOGRAPHIC SCOPE
          </span>
          <span className="rounded-full bg-[#FF2B44]/15 px-2 py-0.5 text-[10px] text-[#FF2B44]">
            {geoLevel.toUpperCase()}
          </span>
        </div>

        {/* Country selector */}
        <div>
          <label className="mb-1 block text-[10px] font-bold uppercase text-[#9CA3AF]">
            Country
          </label>
          <div className="relative">
            <select
              value={selectedCountry}
              onChange={(e) => {
                setSelectedCountry(e.target.value);
                setSelectedState('All States');
                setSelectedRegion('All Regions');
              }}
              className={selectClass}
            >
              {COUNTRIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <ChevronDown
              size={14}
              className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]"
            />
          </div>
        </div>

        {/* State selector (enabled when country is selected) */}
        {selectedCountry !== 'World' && (
          <div>
            <label className="mb-1 block text-[10px] font-bold uppercase text-[#9CA3AF]">
              State
            </label>
            <div className="relative">
              <select
                value={selectedState}
                onChange={(e) => {
                  setSelectedState(e.target.value);
                  setSelectedRegion('All Regions');
                }}
                className={selectClass}
              >
                {availableStates.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              <ChevronDown
                size={14}
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]"
              />
            </div>
          </div>
        )}

        {/* Region selector (enabled when state is selected) */}
        {selectedState !== 'All States' && (
          <div>
            <label className="mb-1 block text-[10px] font-bold uppercase text-[#9CA3AF]">
              Region
            </label>
            <div className="relative">
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className={selectClass}
              >
                {availableRegions.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
              <ChevronDown
                size={14}
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]"
              />
            </div>
          </div>
        )}

        <div className="border-t border-[#262A35] pt-2 text-[11px] font-bold text-[#F3F4F6]">
          {levelLabel}
        </div>
      </div>

      {/* RBAC banner */}
      {userRole !== 'athlete' && (
        <div
          className={`flex items-center gap-2 rounded-xl border px-3.5 py-2.5 text-xs ${
            canEditCurrent
              ? 'border-[#10B981]/30 bg-[#10B981]/10 text-[#10B981]'
              : 'border-[#262A35] bg-[#161920] text-[#9CA3AF]'
          }`}
        >
          {canEditCurrent ? (
            <>
              <ShieldCheck size={14} />
              <span>
                You have edit access to {geoLevel} rankings as{' '}
                {ROLE_LABELS[userRole]}.
              </span>
            </>
          ) : (
            <>
              <Lock size={14} />
              <span>
                {geoLevel === 'regional'
                  ? 'Regional rankings are locked from manual editing (reserved for AI processing).'
                  : `Your ${ROLE_LABELS[userRole]} role cannot edit ${geoLevel} rankings.`}
              </span>
            </>
          )}
        </div>
      )}

      {/* Content */}
      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-[#FF2B44]" />
        </div>
      ) : error ? (
        <div className="flex items-center gap-2 rounded-xl border border-[#FF2B44]/40 bg-[#FF2B44]/10 p-4 text-xs text-[#FF2B44]">
          <AlertCircle size={16} />
          {error}
        </div>
      ) : rankingType === 'player' ? (
        <div className="rounded-2xl border border-[#262A35] bg-[#161920] p-4">
          {players.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#9CA3AF]">
              No ranked players in this category yet.
            </div>
          ) : (
            <div className="divide-y divide-[#262A35]">
              {players.map((player, i) => {
                const totalMatches = player.wins + player.losses;
                const winRate =
                  totalMatches > 0
                    ? Math.round((player.wins / totalMatches) * 100)
                    : 0;
                return (
                  <div
                    key={player.id}
                    className="flex items-center justify-between border-b border-[#262A35] py-3 last:border-0"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-lg font-black text-[#FF2B44]">
                        #{i + 1}
                      </span>
                      <div className="flex h-9 w-9 items-center justify-center rounded-full border border-[#262A35] bg-[#0B0D10] text-xs font-bold text-[#F3F4F6]">
                        {player.fullName.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-[#F3F4F6]">
                          {player.fullName}
                        </h4>
                        <p className="text-[10px] text-[#9CA3AF]">
                          {player.clubName || 'Unaffiliated'} -{' '}
                          {player.weightClass}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-extrabold text-[#FF2B44]">
                        {player.eloRating} pts
                      </div>
                      {totalMatches > 0 && (
                        <span className="text-[10px] font-semibold text-[#10B981]">
                          {winRate}% Win Rate
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        <div className="rounded-2xl border border-[#262A35] bg-[#161920] p-4">
          {lifts.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#9CA3AF]">
              No lift records for this category yet.
            </div>
          ) : (
            <div className="divide-y divide-[#262A35]">
              {lifts.map((lift) => (
                <div
                  key={lift.id}
                  className="flex items-center justify-between border-b border-[#262A35] py-3 last:border-0"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-[#F3F4F6]">
                      {lift.liftType}
                    </span>
                    <span className="text-[10px] text-[#9CA3AF]">
                      {lift.playerName}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-extrabold text-[#10B981]">
                      {lift.weightKg} kg
                    </div>
                    {lift.verified ? (
                      <span className="flex items-center gap-0.5 text-[10px] text-[#10B981]">
                        <Check size={10} /> AI Verified
                      </span>
                    ) : (
                      <span className="text-[10px] text-[#9CA3AF]">
                        Unverified
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Approval workflow info card */}
      <div className="space-y-2 rounded-xl border border-[#262A35] bg-[#161920] p-4">
        <h4 className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
          <Clock size={13} className="text-[#FF2B44]" /> SUBMISSION APPROVAL WORKFLOW
        </h4>
        <div className="space-y-1.5 text-[10px] text-[#9CA3AF]">
          <div className="flex items-center gap-2">
            <span className="flex h-1.5 w-1.5 rounded-full bg-[#10B981]" />
            Regional submissions: auto-approved instantly
          </div>
          <div className="flex items-center gap-2">
            <span className="flex h-1.5 w-1.5 rounded-full bg-[#FF2B44]" />
            State submissions: 24h pending review (Admin / Association)
          </div>
          <div className="flex items-center gap-2">
            <span className="flex h-1.5 w-1.5 rounded-full bg-[#FF2B44]" />
            National submissions: 24h pending review (Federation / Admin)
          </div>
        </div>
      </div>
    </div>
  );
}

const selectClass =
  'w-full appearance-none rounded-xl border border-[#262A35] bg-[#0B0D10] px-3.5 py-2.5 text-sm text-[#F3F4F6] outline-none transition focus:border-[#FF2B44]';
