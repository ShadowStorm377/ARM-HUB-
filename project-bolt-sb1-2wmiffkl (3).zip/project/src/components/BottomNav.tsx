import { Home, Trophy, Cpu, Video, User } from 'lucide-react';

export type TabId = 'feed' | 'ranks' | 'coach' | 'media' | 'profile';

type BottomNavProps = {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
};

const TABS: { id: TabId; label: string; icon: typeof Home }[] = [
  { id: 'feed', label: 'HOME', icon: Home },
  { id: 'ranks', label: 'RANKS', icon: Trophy },
  { id: 'coach', label: 'COACH', icon: Cpu },
  { id: 'media', label: 'MEDIA', icon: Video },
  { id: 'profile', label: 'PROFILE', icon: User },
];

export default function BottomNav({
  activeTab,
  onTabChange,
}: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 mx-auto flex max-w-lg w-full justify-around border-t border-[#262A35] bg-[#0B0D10]/95 px-2 py-1.5 backdrop-blur">
      {TABS.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className="flex flex-col items-center justify-center px-3 py-1 transition-all"
          >
            <div
              className={`flex items-center justify-center rounded-xl px-2.5 py-1 transition-all ${
                isActive
                  ? 'border border-[#FF2B44]/40 text-[#FF2B44]'
                  : 'border border-transparent text-[#9CA3AF] hover:text-[#F3F4F6]'
              }`}
            >
              <Icon size={18} strokeWidth={isActive ? 2.5 : 2} />
            </div>
            <span
              className={`mt-0.5 text-[9px] tracking-wider ${
                isActive ? 'font-bold text-[#FF2B44]' : 'font-medium text-[#9CA3AF]'
              }`}
            >
              {item.label}
            </span>
            {isActive && (
              <div className="mt-0.5 h-1 w-1 rounded-full bg-[#FF2B44] shadow-[0_0_6px_#FF2B44]" />
            )}
          </button>
        );
      })}
    </nav>
  );
}
