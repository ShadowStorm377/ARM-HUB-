import { useState, useEffect, type FormEvent } from 'react';
import {
  X,
  AlertCircle,
  Loader2,
  Eye,
  EyeOff,
  Building2,
  Users,
  Phone,
  MapPin,
  FileText,
  Check,
  Calendar,
} from 'lucide-react';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from 'firebase/auth';
import { auth, db } from '@/lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { useAuth } from '@/context/AuthContext';
import {
  createProfile,
  registerOrganization,
} from '@/lib/firebase-queries';
import {
  WEIGHT_CLASSES,
  COUNTRIES,
  COUNTRY_STATES,
  STATE_REGIONS,
  DISTRICTS,
  ORG_TIERS,
  WAF_BRACKET_LABELS,
  type WeightClass,
  type OrgTier,
  type Profile,
  type UserRole,
  type WAFAgeBracket,
} from '@/lib/types';
import { calculateAge, determineWAFBracket, formatDOB } from '@/lib/waf';

type AuthMode = 'signup' | 'login';
type RegistrationTab = 'athlete' | 'organization';

type AuthModalProps = {
  open: boolean;
  initialMode: AuthMode;
  onClose: () => void;
};

const inputClass =
  'w-full rounded-xl border border-[#262A35] bg-[#0B0D10] px-3.5 py-2.5 text-sm text-[#F3F4F6] outline-none transition focus:border-[#FF2B44] placeholder:text-[#9CA3AF]/50';

const labelClass = 'mb-1 block text-xs font-bold text-[#9CA3AF]';

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className={labelClass}>{label}</label>
      {children}
    </div>
  );
}

function Select({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[] | readonly string[];
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={inputClass}
    >
      {(options as readonly (string | { value: string; label: string })[]).map(
        (opt) => {
          if (typeof opt === 'string') {
            return (
              <option key={opt} value={opt}>
                {opt}
              </option>
            );
          }
          return (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          );
        }
      )}
    </select>
  );
}

function PasswordField({
  label,
  value,
  onChange,
  placeholder,
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  autoComplete?: string;
}) {
  const [show, setShow] = useState(false);
  return (
    <Field label={label}>
      <div className="relative">
        <input
          type={show ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={`${inputClass} pr-9`}
          autoComplete={autoComplete}
          required
        />
        <button
          type="button"
          onClick={() => setShow((s) => !s)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9CA3AF] transition hover:text-[#F3F4F6]"
        >
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
    </Field>
  );
}

function StatusBadge({ status, subtitle }: { status: string; subtitle: string }) {
  return (
    <div className="rounded-xl border border-[#FF2B44]/30 bg-[#FF2B44]/10 p-3">
      <p className="text-xs font-bold text-[#FF2B44]">
        ENTITY DASHBOARD STATUS: {status}
      </p>
      <p className="mt-1 text-[11px] text-[#9CA3AF]">{subtitle}</p>
    </div>
  );
}

// ---- DOB Picker component ----

function DOBPicker({
  day,
  month,
  year,
  onDay,
  onMonth,
  onYear,
}: {
  day: number;
  month: number;
  year: number;
  onDay: (v: number) => void;
  onMonth: (v: number) => void;
  onYear: (v: number) => void;
}) {
  const dobString = formatDOB(day, month, year);
  const age = calculateAge(dobString);
  const bracket: WAFAgeBracket | null = age > 0 ? determineWAFBracket(age) : null;

  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  const months = Array.from({ length: 12 }, (_, i) => i + 1);
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 90 }, (_, i) => currentYear - i);

  return (
    <div>
      <label className={labelClass}>Date of Birth (D/M/YYYY)</label>
      <div className="grid grid-cols-3 gap-2">
        <select
          value={day}
          onChange={(e) => onDay(parseInt(e.target.value, 10))}
          className={inputClass}
        >
          {days.map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
        <select
          value={month}
          onChange={(e) => onMonth(parseInt(e.target.value, 10))}
          className={inputClass}
        >
          {months.map((m) => (
            <option key={m} value={m}>{m}</option>
          ))}
        </select>
        <select
          value={year}
          onChange={(e) => onYear(parseInt(e.target.value, 10))}
          className={inputClass}
        >
          {years.map((y) => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>
      </div>
      {bracket && (
        <div className="mt-2 flex items-center gap-2 rounded-lg border border-[#10B981]/30 bg-[#10B981]/10 px-3 py-2">
          <Calendar size={14} className="text-[#10B981]" />
          <span className="text-[11px] font-bold text-[#10B981]">
            Age {age} - Auto-assigned: {WAF_BRACKET_LABELS[bracket]}
          </span>
        </div>
      )}
    </div>
  );
}

export default function AuthModal({
  open,
  initialMode,
  onClose,
}: AuthModalProps) {
  const { refreshProfile } = useAuth();
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [regTab, setRegTab] = useState<RegistrationTab>('athlete');
  const [orgTier, setOrgTier] = useState<OrgTier>('team');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');

  // Athlete fields
  const [username, setUsername] = useState('');
  const [weightClass, setWeightClass] = useState<WeightClass>('70kg');
  const [country, setCountry] = useState('India');
  const [state, setState] = useState('West Bengal');
  const [district, setDistrict] = useState('Jalpaiguri');
  const [dobDay, setDobDay] = useState(1);
  const [dobMonth, setDobMonth] = useState(1);
  const [dobYear, setDobYear] = useState(new Date().getFullYear() - 20);

  // Org fields
  const [orgName, setOrgName] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [regId, setRegId] = useState('');
  const [address, setAddress] = useState('');
  const [orgEmail, setOrgEmail] = useState('');
  const [orgPassword, setOrgPassword] = useState('');
  const [orgPasswordConfirm, setOrgPasswordConfirm] = useState('');
  const [orgCountry, setOrgCountry] = useState('India');
  const [orgState, setOrgState] = useState('West Bengal');
  const [orgRegion, setOrgRegion] = useState('North Bengal');
  const [docFileName, setDocFileName] = useState<string | null>(null);

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [orgSuccess, setOrgSuccess] = useState(false);

  useEffect(() => {
    if (open) {
      setMode(initialMode);
      setError(null);
      setOrgSuccess(false);
    }
  }, [open, initialMode]);

  const handleClose = () => {
    setError(null);
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setFullName('');
    setUsername('');
    setOrgSuccess(false);
    onClose();
  };

  const handleAthleteSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        await signInWithEmailAndPassword(auth, email.trim(), password);
        await refreshProfile();
        handleClose();
      } else {
        if (!fullName.trim()) throw new Error('Please enter your full name.');
        if (password.length < 6)
          throw new Error('Password must be at least 6 characters long.');
        if (password !== confirmPassword)
          throw new Error('Passwords do not match.');

        const cred = await createUserWithEmailAndPassword(
          auth,
          email.trim(),
          password
        );

        const dobString = formatDOB(dobDay, dobMonth, dobYear);
        const age = calculateAge(dobString);
        const wafBracket = age > 0 ? determineWAFBracket(age) : null;

        const newProfile: Profile = {
          uid: cred.user.uid,
          fullName: fullName.trim(),
          username: username.trim() || null,
          email: email.trim(),
          role: 'athlete' as UserRole,
          dateOfBirth: dobString,
          wafBracket,
          bio: null,
          weightClass,
          primaryArm: 'right',
          country,
          state,
          region: district,
          photoURL: null,
          createdAt: Date.now(),
        };

            try {
      await setDoc(doc(db, "athletes", cred.user.uid), newProfile);
      console.log("Athlete profile successfully written to Firestore!");
    } catch (e) {
      console.error("Failed to write to database:", e);
    }
        await refreshProfile();
        handleClose();
      }
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'An unexpected error occurred.';
      setError(translateFirebaseError(message));
    } finally {
      setLoading(false);
    }
  };

  const handleOrgSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (!orgName.trim()) throw new Error('Please enter the entity name.');
      if (!orgEmail.trim()) throw new Error('Please enter an official email.');
      if (orgPassword.length < 6)
        throw new Error('Password must be at least 6 characters long.');
      if (orgPassword !== orgPasswordConfirm)
        throw new Error('Passwords do not match.');

      const cred = await createUserWithEmailAndPassword(
        auth,
        orgEmail.trim(),
        orgPassword
      );

      const role: UserRole =
        orgTier === 'federation'
          ? 'federation'
          : orgTier === 'association'
          ? 'association'
          : orgTier === 'club'
          ? 'club'
          : 'team';

      const newProfile: Profile = {
        uid: cred.user.uid,
        fullName: orgName.trim(),
        username: null,
        email: orgEmail.trim(),
        role,
        dateOfBirth: null,
        wafBracket: null,
        bio: null,
        weightClass: null,
        primaryArm: 'right',
        country: orgCountry,
        state: orgState,
        region: orgRegion,
        photoURL: null,
        createdAt: Date.now(),
      };

      try {
        await createProfile(newProfile);
      } catch {
        // Non-fatal
      }

      try {
        await registerOrganization(
          orgTier,
          orgName.trim(),
          contactName.trim(),
          contactPhone.trim(),
          orgEmail.trim(),
          regId.trim() || undefined,
          address.trim() || undefined,
          undefined,
          orgCountry,
          orgState,
          orgRegion,
          docFileName || undefined
        );
      } catch {
        // Non-fatal
      }

      setOrgSuccess(true);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'An unexpected error occurred.';
      setError(translateFirebaseError(message));
    } finally {
      setLoading(false);
    }
  };

  if (!open) return null;
  const isSignUp = mode === 'signup';

  const tierLabel =
    ORG_TIERS.find((t) => t.value === orgTier)?.label || 'Team';

  const availableStates = country === 'India' ? COUNTRY_STATES['India'] : ['All States'];
  const availableRegions = state && STATE_REGIONS[state] ? STATE_REGIONS[state] : ['All Regions'];

  // Org tier button labels: Team, Club, Association, Federation
  const orgTierLabels: Record<OrgTier, string> = {
    team: 'Team',
    club: 'Club',
    association: 'Association',
    federation: 'Federation',
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
    >
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={handleClose}
      />

      <div className="relative max-h-[92vh] w-full max-w-md overflow-y-auto rounded-2xl border border-[#262A35] bg-[#12141A] shadow-2xl scrollbar-none">
        <div className="sticky top-0 z-10 border-b border-[#262A35] bg-[#12141A] px-5 py-4">
          <button
            onClick={handleClose}
            className="absolute right-4 top-4 text-[#9CA3AF] transition hover:text-[#F3F4F6]"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#FF2B44] text-sm font-black text-white shadow-lg shadow-[#FF2B44]/30">
              AH
            </div>
            <div>
              <h2 className="text-base font-black text-[#F3F4F6]">
                {isSignUp ? 'JOIN THE HUB' : 'SIGN IN'}
              </h2>
              <p className="text-[11px] text-[#9CA3AF]">
                Global Armwrestling Platform
              </p>
            </div>
          </div>

          {isSignUp && (
            <div className="mt-4 grid grid-cols-2 gap-2 rounded-xl border border-[#262A35] bg-[#0B0D10] p-1">
              <button
                type="button"
                onClick={() => setRegTab('athlete')}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-bold transition-all ${
                  regTab === 'athlete'
                    ? 'bg-[#FF2B44] text-white'
                    : 'text-[#9CA3AF] hover:text-[#F3F4F6]'
                }`}
              >
                <Users size={14} />
                Athlete
              </button>
              <button
                type="button"
                onClick={() => setRegTab('organization')}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-bold transition-all ${
                  regTab === 'organization'
                    ? 'bg-[#FF2B44] text-white'
                    : 'text-[#9CA3AF] hover:text-[#F3F4F6]'
                }`}
              >
                <Building2 size={14} />
                Organization
              </button>
            </div>
          )}
        </div>

        <div className="px-5 py-5">
          {error && (
            <div className="mb-4 flex items-start gap-2 rounded-lg border border-[#FF2B44]/40 bg-[#FF2B44]/10 px-3 py-2.5">
              <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-[#FF2B44]" />
              <p className="text-xs font-medium text-[#FF2B44]">{error}</p>
            </div>
          )}

          {orgSuccess ? (
            <div className="space-y-4 py-6 text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#10B981]/15 text-[#10B981]">
                <Check size={28} />
              </div>
              <h3 className="text-base font-bold text-[#F3F4F6]">
                {orgTier === 'team' ? 'Team Registered!' : 'Submission Received!'}
              </h3>
              <p className="text-xs text-[#9CA3AF]">
                {orgTier === 'team'
                  ? 'Your team dashboard is activated immediately. You can now sign in.'
                  : `Your ${tierLabel} registration is under review. You'll receive an update within 24 hours.`}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setOrgSuccess(false);
                    setMode('login');
                    setRegTab('athlete');
                    setEmail(orgEmail);
                  }}
                  className="flex-1 rounded-xl bg-[#FF2B44] py-2.5 text-xs font-bold text-white transition hover:bg-[#e8243c]"
                >
                  Continue to Sign In
                </button>
                <button
                  onClick={handleClose}
                  className="flex-1 rounded-xl border border-[#262A35] bg-[#161920] py-2.5 text-xs font-bold text-[#9CA3AF] transition hover:text-[#F3F4F6]"
                >
                  Close
                </button>
              </div>
            </div>
          ) : !isSignUp ? (
            <form onSubmit={handleAthleteSubmit} className="space-y-3">
              <Field label="Email Address">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className={inputClass}
                  autoComplete="email"
                  required
                />
              </Field>
              <PasswordField
                label="Password"
                value={password}
                onChange={setPassword}
                placeholder="------"
                autoComplete="current-password"
              />
              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#FF2B44] py-2.5 text-sm font-bold text-white transition hover:bg-[#e8243c] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                Sign In
              </button>
              <div className="pt-1 text-center text-xs text-[#9CA3AF]">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('signup')}
                  className="font-bold text-[#FF2B44]"
                >
                  Create Account
                </button>
              </div>
            </form>
          ) : regTab === 'athlete' ? (
            <form onSubmit={handleAthleteSubmit} className="space-y-3">
              <Field label="Full Name">
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Your name"
                  className={inputClass}
                  autoComplete="name"
                  required
                />
              </Field>
              <Field label="@ Username">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.replace(/\s/g, ''))}
                  placeholder="username"
                  className={inputClass}
                  autoComplete="username"
                />
              </Field>
              <Field label="Email Address">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className={inputClass}
                  autoComplete="email"
                  required
                />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <PasswordField
                  label="Password"
                  value={password}
                  onChange={setPassword}
                  placeholder="------"
                  autoComplete="new-password"
                />
                <PasswordField
                  label="Confirm"
                  value={confirmPassword}
                  onChange={setConfirmPassword}
                  placeholder="------"
                  autoComplete="new-password"
                />
              </div>
              <Field label="Weight Class">
                <Select
                  value={weightClass}
                  onChange={(v) => setWeightClass(v as WeightClass)}
                  options={WEIGHT_CLASSES}
                />
              </Field>
              <DOBPicker
                day={dobDay}
                month={dobMonth}
                year={dobYear}
                onDay={setDobDay}
                onMonth={setDobMonth}
                onYear={setDobYear}
              />
              <div className="grid grid-cols-3 gap-3">
                <Field label="Country">
                  <Select
                    value={country}
                    onChange={(v) => {
                      setCountry(v);
                      const states = COUNTRY_STATES[v];
                      if (states) setState(states[0]);
                    }}
                    options={COUNTRIES.filter((c) => c !== 'World')}
                  />
                </Field>
                <Field label="State">
                  <Select
                    value={state}
                    onChange={(v) => {
                      setState(v);
                      const regions = STATE_REGIONS[v];
                      if (regions) setDistrict(regions[0]);
                    }}
                    options={availableStates.filter((s) => s !== 'All States')}
                  />
                </Field>
                <Field label="Region / District">
                  <Select
                    value={district}
                    onChange={setDistrict}
                    options={
                      availableRegions.includes('All Regions')
                        ? DISTRICTS
                        : availableRegions
                    }
                  />
                </Field>
              </div>
              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#FF2B44] py-3 text-sm font-bold text-white shadow-lg shadow-[#FF2B44]/20 transition hover:bg-[#e8243c] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Users size={16} />
                )}
                Register as Athlete
              </button>
              <div className="pt-1 text-center text-xs text-[#9CA3AF]">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="font-bold text-[#FF2B44]"
                >
                  Log in
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleOrgSubmit} className="space-y-4">
              <Field label="Organization Tier">
                <div className="grid grid-cols-4 gap-1.5 rounded-xl border border-[#262A35] bg-[#0B0D10] p-1.5">
                  {ORG_TIERS.map((tier) => (
                    <button
                      key={tier.value}
                      type="button"
                      onClick={() => setOrgTier(tier.value)}
                      className={`rounded-lg py-2 text-[10px] font-bold transition-all ${
                        orgTier === tier.value
                          ? 'bg-[#FF2B44] text-white'
                          : 'text-[#9CA3AF] hover:text-[#F3F4F6]'
                      }`}
                    >
                      {orgTierLabels[tier.value]}
                    </button>
                  ))}
                </div>
              </Field>

              {orgTier === 'team' ? (
                <StatusBadge
                  status="Approved instantly"
                  subtitle="Team registrations are activated immediately."
                />
              ) : orgTier === 'club' ? (
                <StatusBadge
                  status="Under Review - 12h SLA"
                  subtitle="Basic affiliation documents are reviewed by an administrator."
                />
              ) : (
                <StatusBadge
                  status="Under Review - 24h SLA"
                  subtitle="Strict verification is required for official entities."
                />
              )}

              <Field
                label={
                  orgTier === 'team'
                    ? 'Team Name'
                    : orgTier === 'club'
                    ? 'Club Name'
                    : orgTier === 'association'
                    ? 'Legal Entity Name'
                    : 'Federation Name'
                }
              >
                <input
                  type="text"
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  placeholder="Entity name"
                  className={inputClass}
                  required
                />
              </Field>

              <Field
                label={
                  orgTier === 'team'
                    ? 'Captain Name'
                    : orgTier === 'club'
                    ? 'Head Coach / Captain'
                    : 'President / Secretary Names'
                }
              >
                <input
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="Contact person"
                  className={inputClass}
                />
              </Field>

              <div className="grid grid-cols-2 gap-3">
                <Field label="Contact Phone">
                  <div className="relative">
                    <input
                      type="tel"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      placeholder="+91..."
                      className={`${inputClass} pl-8`}
                    />
                    <Phone
                      size={13}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]"
                    />
                  </div>
                </Field>
                {orgTier !== 'team' && (
                  <Field
                    label={
                      orgTier === 'club' ? 'Affiliation ID' : 'Registration Number'
                    }
                  >
                    <input
                      type="text"
                      value={regId}
                      onChange={(e) => setRegId(e.target.value)}
                      placeholder="ID number"
                      className={inputClass}
                    />
                  </Field>
                )}
              </div>

              {orgTier === 'team' ? (
                <Field label="Base City / District">
                  <div className="relative">
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="City"
                      className={`${inputClass} pl-8`}
                    />
                    <MapPin
                      size={13}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]"
                    />
                  </div>
                </Field>
              ) : (
                <Field
                  label={
                    orgTier === 'club'
                      ? 'Gym Address'
                      : 'Official Headquarters Address'
                  }
                >
                  <div className="relative">
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Full address"
                      className={`${inputClass} pl-8`}
                    />
                    <MapPin
                      size={13}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]"
                    />
                  </div>
                </Field>
              )}

              <Field label="Official Email Address">
                <input
                  type="email"
                  value={orgEmail}
                  onChange={(e) => setOrgEmail(e.target.value)}
                  placeholder="official@entity.org"
                  className={inputClass}
                  required
                />
              </Field>

              <div className="grid grid-cols-2 gap-3">
                <PasswordField
                  label="Password"
                  value={orgPassword}
                  onChange={setOrgPassword}
                  placeholder="------"
                  autoComplete="new-password"
                />
                <PasswordField
                  label="Confirm Password"
                  value={orgPasswordConfirm}
                  onChange={setOrgPasswordConfirm}
                  placeholder="------"
                  autoComplete="new-password"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <Field label="Country">
                  <Select
                    value={orgCountry}
                    onChange={setOrgCountry}
                    options={COUNTRIES.filter((c) => c !== 'World')}
                  />
                </Field>
                <Field label="State">
                  <Select
                    value={orgState}
                    onChange={setOrgState}
                    options={COUNTRY_STATES['India'].filter((s) => s !== 'All States')}
                  />
                </Field>
                <Field label="Region / District">
                  <Select
                    value={orgRegion}
                    onChange={setOrgRegion}
                    options={['North Bengal', ...DISTRICTS]}
                  />
                </Field>
              </div>

              {orgTier !== 'team' && (
                <div>
                  <label className={labelClass}>
                    {orgTier === 'club'
                      ? 'AFFILIATION DOCUMENT'
                      : 'AFFILIATION CERTIFICATE'}
                  </label>
                  <label className="block w-full">
                    <input
                      type="file"
                      accept=".pdf,.jpg,.png,.doc,.docx"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) setDocFileName(f.name);
                      }}
                    />
                    <div className="flex cursor-pointer items-center gap-2 rounded-xl border border-[#FF2B44]/30 bg-[#FF2B44]/10 px-3.5 py-2.5 text-xs font-bold text-[#FF2B44] transition hover:bg-[#FF2B44]/20">
                      <FileText size={14} />
                      Choose File
                    </div>
                  </label>
                  {docFileName && (
                    <p className="mt-1.5 flex items-center gap-1 text-[10px] text-[#10B981]">
                      <Check size={11} /> {docFileName}
                    </p>
                  )}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#FF2B44] py-3 text-sm font-bold text-white shadow-lg shadow-[#FF2B44]/20 transition hover:bg-[#e8243c] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Building2 size={16} />
                )}
                {orgTier === 'team'
                  ? 'Register Team'
                  : orgTier === 'club'
                  ? 'Submit Club for Review'
                  : orgTier === 'association'
                  ? 'Submit Association for Review'
                  : 'Submit Federation for Review'}
              </button>

              <div className="pt-1 text-center text-xs text-[#9CA3AF]">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="font-bold text-[#FF2B44]"
                >
                  Log in
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

function translateFirebaseError(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes('invalid-credential') || lower.includes('wrong-password') || lower.includes('invalid-login'))
    return 'Incorrect email or password. Please try again.';
  if (lower.includes('email-already-in-use'))
    return 'An account with this email already exists. Try signing in instead.';
  if (lower.includes('weak-password'))
    return 'Password is too weak. Use at least 6 characters.';
  if (lower.includes('email-not-verified'))
    return 'Your email has not been verified yet. Please check your inbox.';
  if (lower.includes('network') || lower.includes('fetch') || lower.includes('unavailable'))
    return 'Network error. Please check your connection and try again.';
  if (lower.includes('too-many-requests'))
    return 'Too many attempts. Please wait a minute and try again.';
  if (lower.includes('operation-not-allowed'))
    return 'This operation is not allowed. Please contact support.';
  return message;
}
