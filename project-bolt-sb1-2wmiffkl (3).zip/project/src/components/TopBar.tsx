import { useState } from 'react';
import { ShieldCheck, Menu } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import HamburgerMenu from '@/components/HamburgerMenu';

export type NavPill = 'athletes' | 'host' | 'news' | 'playlists' | 'community' | 'records';

type TopBarProps = {
  onOpenAuth: (mode: 'signup' | 'login') => void;
  activePill: NavPill;
  onPillChange: (pill: NavPill) => void;
};

const NAV_PILLS: { id: NavPill; label: string }[] = [
  { id: 'athletes', label: 'Athletes' },
  { id: 'host', label: 'Host' },
  { id: 'news', label: 'News' },
  { id: 'playlists', label: 'Playlists' },
  { id: 'community', label: 'Community' },
  { id: 'records', label: 'Records' },
];

export default function TopBar({ onOpenAuth, activePill, onPillChange }: TopBarProps) {
  const { user, profile } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const firstName = profile?.fullName?.split(' ')[0] || 'USER';
  const isAdmin = profile?.role === 'admin';

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-[#262A35] bg-[#0B0D10]/95 px-4 py-3 backdrop-blur">
        <div className="mx-auto flex max-w-lg items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#FF2B44] text-sm font-black tracking-wider text-white shadow-lg shadow-[#FF2B44]/30">
              AH
            </div>
            <div>
              <h1 className="text-sm font-extrabold tracking-wide text-[#F3F4F6]">
                ARMWRESTLING<span className="text-[#FF2B44]">HUB</span>
              </h1>
              <p className="text-[10px] font-medium uppercase tracking-wider text-[#9CA3AF]">
                North Bengal Assn
              </p>
            </div>
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2">
            {user ? (
              <>
                {isAdmin && (
                  <span className="hidden items-center gap-1 rounded-full border border-[#FF2B44]/40 bg-[#FF2B44]/15 px-2.5 py-1 text-[11px] font-semibold text-[#FF2B44] sm:flex">
                    <ShieldCheck size={13} />
                    ADMIN
                  </span>
                )}
                <div className="flex items-center gap-1.5 rounded-full border border-[#262A35] bg-[#161920] px-2.5 py-1 text-[11px] font-semibold text-[#F3F4F6]">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#10B981]" />
                  {firstName}
                </div>
              </>
            ) : (
              <>
                <button
                  onClick={() => onOpenAuth('login')}
                  className="rounded-full px-3 py-1.5 text-[11px] font-bold text-[#9CA3AF] transition hover:text-[#F3F4F6]"
                >
                  Log In
                </button>
                <button
                  onClick={() => onOpenAuth('signup')}
                  className="rounded-full bg-[#FF2B44] px-4 py-1.5 text-[11px] font-bold text-white shadow-lg shadow-[#FF2B44]/20 transition hover:bg-[#e8243c]"
                >
                  Sign Up
                </button>
              </>
            )}

            {/* Hamburger */}
            <button
              onClick={() => setMenuOpen(true)}
              className="ml-1 flex h-8 w-8 items-center justify-center rounded-lg border border-[#262A35] bg-[#161920] text-[#9CA3AF] transition hover:text-[#F3F4F6]"
              aria-label="Menu"
            >
              <Menu size={16} />
            </button>
          </div>
        </div>

        {/* Top navigation pills */}
        <div className="scrollbar-none mx-auto mt-3 flex max-w-lg gap-1.5 overflow-x-auto pb-0.5">
          {NAV_PILLS.map((pill) => (
            <button
              key={pill.id}
              onClick={() => onPillChange(pill.id)}
              className={`whitespace-nowrap rounded-full px-3 py-1 text-[11px] font-bold transition-all ${
                activePill === pill.id
                  ? 'bg-[#FF2B44] text-white'
                  : 'border border-[#262A35] bg-[#161920] text-[#9CA3AF] hover:text-[#F3F4F6]'
              }`}
            >
              {pill.label}
            </button>
          ))}
        </div>
      </header>

      <HamburgerMenu
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
        onOpenAuth={onOpenAuth}
      />
    </>
  );
}
