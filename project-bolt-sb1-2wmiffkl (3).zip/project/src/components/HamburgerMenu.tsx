import { useState, useEffect, useCallback } from 'react';
import {
  X,
  Moon,
  Sun,
  LogOut,
  Pencil,
  Building2,
  Check,
  Loader2,
  AlertCircle,
  User,
  ArrowLeftRight,
  Camera,
  Users,
  Phone,
  MapPin,
  FileText,
  ShieldCheck,
  Calendar,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { updateProfile, fetchUserOrganizations, registerOrganization } from '@/lib/firebase-queries';
import {
  ROLE_LABELS,
  WAF_BRACKET_LABELS,
  ORG_TIERS,
  COUNTRIES,
  COUNTRY_STATES,
  DISTRICTS,
  type OrgTier,
  type Organization,
  type ViewMode,
} from '@/lib/types';
import { calculateAge, determineWAFBracket, formatDOB, recalculateBracket } from '@/lib/waf';

type HamburgerMenuProps = {
  open: boolean;
  onClose: () => void;
  onOpenAuth: (mode: 'signup' | 'login') => void;
};

type MenuSection = 'main' | 'editProfile' | 'orgManagement' | 'createOrg';

const inputClass =
  'w-full rounded-xl border border-[#262A35] bg-[#0B0D10] px-3.5 py-2.5 text-sm text-[#F3F4F6] outline-none transition focus:border-[#FF2B44] placeholder:text-[#9CA3AF]/50';

const labelClass = 'mb-1 block text-xs font-bold text-[#9CA3AF]';

export default function HamburgerMenu({ open, onClose, onOpenAuth }: HamburgerMenuProps) {
  const { user, profile, signOut, theme, toggleTheme, viewMode, setViewMode, refreshProfile } = useAuth();
  const [section, setSection] = useState<MenuSection>('main');

  // Edit profile state
  const [editUsername, setEditUsername] = useState('');
  const [editFullName, setEditFullName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editDobDay, setEditDobDay] = useState(1);
  const [editDobMonth, setEditDobMonth] = useState(1);
  const [editDobYear, setEditDobYear] = useState(new Date().getFullYear() - 20);
  const [editPhotoName, setEditPhotoName] = useState<string | null>(null);
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);

  // Org management state
  const [orgs, setOrgs] = useState<Organization[]>([]);
  const [orgsLoading, setOrgsLoading] = useState(false);

  // Create org state
  const [createTier, setCreateTier] = useState<OrgTier>('team');
  const [createName, setCreateName] = useState('');
  const [createContact, setCreateContact] = useState('');
  const [createPhone, setCreatePhone] = useState('');
  const [createRegId, setCreateRegId] = useState('');
  const [createAddress, setCreateAddress] = useState('');
  const [createCountry, setCreateCountry] = useState('India');
  const [createState, setCreateState] = useState('West Bengal');
  const [createRegion, setCreateRegion] = useState('North Bengal');
  const [createDocName, setCreateDocName] = useState<string | null>(null);
  const [creatingOrg, setCreatingOrg] = useState(false);
  const [orgError, setOrgError] = useState<string | null>(null);
  const [orgCreated, setOrgCreated] = useState(false);

  useEffect(() => {
    if (profile) {
      setEditUsername(profile.username || '');
      setEditFullName(profile.fullName);
      setEditEmail(profile.email);
      if (profile.dateOfBirth) {
        const parts = profile.dateOfBirth.split('/');
        if (parts.length === 3) {
          setEditDobDay(parseInt(parts[0], 10) || 1);
          setEditDobMonth(parseInt(parts[1], 10) || 1);
          setEditDobYear(parseInt(parts[2], 10) || 2000);
        }
      }
    }
  }, [profile]);

  useEffect(() => {
    if (!open) {
      setSection('main');
      setProfileError(null);
      setOrgError(null);
      setOrgCreated(false);
    }
  }, [open]);

  const loadOrgs = useCallback(async () => {
    if (!user?.uid) return;
    setOrgsLoading(true);
    try {
      const data = await fetchUserOrganizations(user.uid);
      setOrgs(data);
    } catch {
      // ignore
    } finally {
      setOrgsLoading(false);
    }
  }, [user?.uid]);

  useEffect(() => {
    if (open && section === 'orgManagement' && user) {
      loadOrgs();
    }
  }, [open, section, user, loadOrgs]);

  const handleSaveProfile = async () => {
    if (!user) return;
    setSavingProfile(true);
    setProfileError(null);
    try {
      const dobString = formatDOB(editDobDay, editDobMonth, editDobYear);
      const wafBracket = recalculateBracket(dobString);
      await updateProfile(user.uid, {
        fullName: editFullName.trim(),
        username: editUsername.trim() || null,
        email: editEmail.trim(),
        dateOfBirth: dobString,
        wafBracket,
        photoURL: editPhotoName ? `profile_photos/${user.uid}/${editPhotoName}` : profile?.photoURL ?? null,
      });
      await refreshProfile();
      setSection('main');
    } catch (err) {
      setProfileError(err instanceof Error ? err.message : 'Failed to save profile.');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleCreateOrg = async () => {
    if (!user) return;
    setCreatingOrg(true);
    setOrgError(null);
    try {
      if (!createName.trim()) throw new Error('Please enter the entity name.');
      await registerOrganization(
        createTier,
        createName.trim(),
        createContact.trim(),
        createPhone.trim(),
        profile?.email || user.email || '',
        createRegId.trim() || undefined,
        createAddress.trim() || undefined,
        undefined,
        createCountry,
        createState,
        createRegion,
        createDocName || undefined
      );
      setOrgCreated(true);
      setCreateName('');
      setCreateContact('');
      setCreatePhone('');
      setCreateRegId('');
      setCreateAddress('');
      setCreateDocName(null);
      await loadOrgs();
    } catch (err) {
      setOrgError(err instanceof Error ? err.message : 'Failed to create organization.');
    } finally {
      setCreatingOrg(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    onClose();
  };

  if (!open) return null;

  const userRole = profile?.role || 'athlete';
  const hasOrgRole = userRole !== 'athlete';
  const currentBracketLabel = profile?.wafBracket ? WAF_BRACKET_LABELS[profile.wafBracket] : 'Not set';

  // ---- Main section ----

  if (section === 'main') {
    return (
      <div className="fixed inset-0 z-[100]" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
        <div className="absolute right-0 top-0 h-full w-[85%] max-w-sm overflow-y-auto border-l border-[#262A35] bg-[#12141A] scrollbar-none">
          <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#262A35] bg-[#12141A] px-4 py-3.5">
            <h3 className="text-sm font-black text-[#F3F4F6]">MENU</h3>
            <button onClick={onClose} className="text-[#9CA3AF] transition hover:text-[#F3F4F6]">
              <X size={18} />
            </button>
          </div>

          <div className="space-y-4 p-4">
            {/* User info */}
            {user ? (
              <div className="rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-[#FF2B44] bg-[#0B0D10] text-sm font-black text-[#F3F4F6]">
                    {(profile?.fullName || user.email || '?').charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-[#F3F4F6]">
                      {profile?.fullName || 'Athlete'}
                    </p>
                    <p className="truncate text-[11px] text-[#9CA3AF]">{user.email}</p>
                    <div className="mt-1 flex items-center gap-1.5">
                      <span className="rounded-full bg-[#FF2B44]/15 px-2 py-0.5 text-[9px] font-bold text-[#FF2B44]">
                        {ROLE_LABELS[userRole]}
                      </span>
                      <span className="text-[9px] text-[#9CA3AF]">{currentBracketLabel}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-2 rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
                <p className="text-xs text-[#9CA3AF]">Sign in to access your dashboard</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => { onOpenAuth('login'); onClose(); }}
                    className="flex-1 rounded-lg border border-[#262A35] py-2 text-xs font-bold text-[#9CA3AF] transition hover:text-[#F3F4F6]"
                  >
                    Log In
                  </button>
                  <button
                    onClick={() => { onOpenAuth('signup'); onClose(); }}
                    className="flex-1 rounded-lg bg-[#FF2B44] py-2 text-xs font-bold text-white transition hover:bg-[#e8243c]"
                  >
                    Sign Up
                  </button>
                </div>
              </div>
            )}

            {/* Theme toggle */}
            <button
              onClick={toggleTheme}
              className="flex w-full items-center justify-between rounded-xl border border-[#262A35] bg-[#161920] px-3.5 py-3 transition hover:border-[#9CA3AF]"
            >
              <span className="flex items-center gap-2.5 text-xs font-bold text-[#F3F4F6]">
                {theme === 'dark' ? <Moon size={16} className="text-[#9CA3AF]" /> : <Sun size={16} className="text-[#FF2B44]" />}
                {theme === 'dark' ? 'Dark Mode' : 'Light Mode'}
              </span>
              <div className={`relative h-5 w-9 rounded-full transition ${theme === 'dark' ? 'bg-[#FF2B44]' : 'bg-[#262A35]'}`}>
                <div className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${theme === 'dark' ? 'left-0.5' : 'left-4'}`} />
              </div>
            </button>

            {/* Edit Profile */}
            {user && (
              <button
                onClick={() => setSection('editProfile')}
                className="flex w-full items-center gap-3 rounded-xl border border-[#262A35] bg-[#161920] px-3.5 py-3 text-left transition hover:border-[#9CA3AF]"
              >
                <Pencil size={16} className="text-[#9CA3AF]" />
                <span className="text-xs font-bold text-[#F3F4F6]">Edit Profile</span>
              </button>
            )}

            {/* Organization Management */}
            {user && (
              <button
                onClick={() => setSection('orgManagement')}
                className="flex w-full items-center gap-3 rounded-xl border border-[#262A35] bg-[#161920] px-3.5 py-3 text-left transition hover:border-[#9CA3AF]"
              >
                <Building2 size={16} className="text-[#9CA3AF]" />
                <span className="text-xs font-bold text-[#F3F4F6]">Organization Management</span>
              </button>
            )}

            {/* Role switching */}
            {user && hasOrgRole && (
              <div className="rounded-xl border border-[#262A35] bg-[#161920] p-3.5">
                <div className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                  <ArrowLeftRight size={13} className="text-[#FF2B44]" />
                  DASHBOARD VIEW
                </div>
                <div className="grid grid-cols-2 gap-1.5 rounded-lg border border-[#262A35] bg-[#0B0D10] p-1">
                  <button
                    onClick={() => setViewMode('athlete' as ViewMode)}
                    className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-[11px] font-bold transition-all ${
                      viewMode === 'athlete' ? 'bg-[#FF2B44] text-white' : 'text-[#9CA3AF] hover:text-[#F3F4F6]'
                    }`}
                  >
                    <User size={13} />
                    Athlete
                  </button>
                  <button
                    onClick={() => setViewMode('organization' as ViewMode)}
                    className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-[11px] font-bold transition-all ${
                      viewMode === 'organization' ? 'bg-[#FF2B44] text-white' : 'text-[#9CA3AF] hover:text-[#F3F4F6]'
                    }`}
                  >
                    <Building2 size={13} />
                    Organization
                  </button>
                </div>
                <p className="mt-2 text-[10px] text-[#9CA3AF]">
                  Currently viewing: {viewMode === 'athlete' ? 'Athlete Dashboard' : 'Organization Dashboard'}
                </p>
              </div>
            )}

            {/* Logout */}
            {user && (
              <button
                onClick={handleSignOut}
                className="flex w-full items-center gap-3 rounded-xl border border-[#FF2B44]/30 bg-[#FF2B44]/10 px-3.5 py-3 text-left transition hover:bg-[#FF2B44]/20"
              >
                <LogOut size={16} className="text-[#FF2B44]" />
                <span className="text-xs font-bold text-[#FF2B44]">Log Out</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ---- Edit Profile section ----

  if (section === 'editProfile') {
    const dobString = formatDOB(editDobDay, editDobMonth, editDobYear);
    const age = calculateAge(dobString);
    const bracket = age > 0 ? determineWAFBracket(age) : null;

    return (
      <div className="fixed inset-0 z-[100]" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
        <div className="absolute right-0 top-0 h-full w-[85%] max-w-sm overflow-y-auto border-l border-[#262A35] bg-[#12141A] scrollbar-none">
          <div className="sticky top-0 z-10 flex items-center gap-3 border-b border-[#262A35] bg-[#12141A] px-4 py-3.5">
            <button onClick={() => setSection('main')} className="text-[#9CA3AF] transition hover:text-[#F3F4F6]">
              <ArrowLeftRight size={16} className="rotate-180" />
            </button>
            <h3 className="text-sm font-black text-[#F3F4F6]">EDIT PROFILE</h3>
            <button onClick={onClose} className="ml-auto text-[#9CA3AF] transition hover:text-[#F3F4F6]">
              <X size={18} />
            </button>
          </div>

          <div className="space-y-4 p-4">
            {/* Profile picture */}
            <div className="flex flex-col items-center gap-2">
              <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-[#FF2B44] bg-[#0B0D10] text-2xl font-black text-[#F3F4F6]">
                {(editFullName || '?').charAt(0).toUpperCase()}
              </div>
              <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-[#262A35] bg-[#161920] px-3 py-1.5 text-[11px] font-bold text-[#9CA3AF] transition hover:text-[#F3F4F6]">
                <Camera size={13} />
                Change Photo
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) setEditPhotoName(f.name);
                  }}
                />
              </label>
              {editPhotoName && (
                <p className="flex items-center gap-1 text-[10px] text-[#10B981]">
                  <Check size={11} /> {editPhotoName}
                </p>
              )}
            </div>

            <div>
              <label className={labelClass}>Full Name</label>
              <input
                type="text"
                value={editFullName}
                onChange={(e) => setEditFullName(e.target.value)}
                className={inputClass}
              />
            </div>
            <div>
              <label className={labelClass}>@ Username</label>
              <input
                type="text"
                value={editUsername}
                onChange={(e) => setEditUsername(e.target.value.replace(/\s/g, ''))}
                placeholder="username"
                className={inputClass}
              />
            </div>
            <div>
              <label className={labelClass}>Email</label>
              <input
                type="email"
                value={editEmail}
                onChange={(e) => setEditEmail(e.target.value)}
                className={inputClass}
              />
            </div>

            {/* DOB */}
            <div>
              <label className={labelClass}>Date of Birth (D/M/YYYY)</label>
              <div className="grid grid-cols-3 gap-2">
                <select value={editDobDay} onChange={(e) => setEditDobDay(parseInt(e.target.value, 10))} className={inputClass}>
                  {Array.from({ length: 31 }, (_, i) => i + 1).map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
                <select value={editDobMonth} onChange={(e) => setEditDobMonth(parseInt(e.target.value, 10))} className={inputClass}>
                  {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
                <select value={editDobYear} onChange={(e) => setEditDobYear(parseInt(e.target.value, 10))} className={inputClass}>
                  {Array.from({ length: 90 }, (_, i) => new Date().getFullYear() - i).map((y) => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>
              {bracket && (
                <div className="mt-2 flex items-center gap-2 rounded-lg border border-[#10B981]/30 bg-[#10B981]/10 px-3 py-2">
                  <Calendar size={14} className="text-[#10B981]" />
                  <span className="text-[11px] font-bold text-[#10B981]">
                    Age {age} - {WAF_BRACKET_LABELS[bracket]}
                  </span>
                </div>
              )}
            </div>

            {profileError && (
              <div className="flex items-center gap-2 rounded-lg border border-[#FF2B44]/40 bg-[#FF2B44]/10 px-3 py-2 text-xs text-[#FF2B44]">
                <AlertCircle size={14} />
                {profileError}
              </div>
            )}

            <button
              onClick={handleSaveProfile}
              disabled={savingProfile}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#FF2B44] py-3 text-sm font-bold text-white transition hover:bg-[#e8243c] disabled:opacity-60"
            >
              {savingProfile ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
              Save Changes
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ---- Organization Management section ----

  if (section === 'orgManagement') {
    return (
      <div className="fixed inset-0 z-[100]" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
        <div className="absolute right-0 top-0 h-full w-[85%] max-w-sm overflow-y-auto border-l border-[#262A35] bg-[#12141A] scrollbar-none">
          <div className="sticky top-0 z-10 flex items-center gap-3 border-b border-[#262A35] bg-[#12141A] px-4 py-3.5">
            <button onClick={() => setSection('main')} className="text-[#9CA3AF] transition hover:text-[#F3F4F6]">
              <ArrowLeftRight size={16} className="rotate-180" />
            </button>
            <h3 className="text-sm font-black text-[#F3F4F6]">ORG MANAGEMENT</h3>
            <button onClick={onClose} className="ml-auto text-[#9CA3AF] transition hover:text-[#F3F4F6]">
              <X size={18} />
            </button>
          </div>

          <div className="space-y-4 p-4">
            {/* Existing orgs */}
            <div>
              <h4 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                Your Organizations
              </h4>
              {orgsLoading ? (
                <div className="flex justify-center py-6">
                  <Loader2 className="h-5 w-5 animate-spin text-[#FF2B44]" />
                </div>
              ) : orgs.length === 0 ? (
                <div className="rounded-xl border border-[#262A35] bg-[#161920] p-4 text-center text-xs text-[#9CA3AF]">
                  No organizations yet. Create one below.
                </div>
              ) : (
                <div className="space-y-2">
                  {orgs.map((org) => (
                    <div key={org.id} className="rounded-xl border border-[#262A35] bg-[#161920] p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h5 className="text-xs font-bold text-[#F3F4F6]">{org.name}</h5>
                          <p className="text-[10px] text-[#9CA3AF] capitalize">{org.tier}</p>
                        </div>
                        <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${
                          org.status === 'approved'
                            ? 'bg-[#10B981]/15 text-[#10B981]'
                            : 'bg-[#FF2B44]/15 text-[#FF2B44]'
                        }`}>
                          {org.status === 'approved' ? 'ACTIVE' : 'PENDING'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Create org button */}
            {orgCreated ? (
              <div className="space-y-3 rounded-xl border border-[#10B981]/30 bg-[#10B981]/10 p-4 text-center">
                <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-[#10B981]/15 text-[#10B981]">
                  <Check size={20} />
                </div>
                <p className="text-xs font-bold text-[#10B981]">
                  {createTier === 'team' ? 'Team created successfully!' : 'Submission received! Under review.'}
                </p>
                <button
                  onClick={() => setOrgCreated(false)}
                  className="rounded-lg border border-[#262A35] bg-[#161920] px-4 py-2 text-[11px] font-bold text-[#9CA3AF] transition hover:text-[#F3F4F6]"
                >
                  Create Another
                </button>
              </div>
            ) : (
              <button
                onClick={() => setSection('createOrg')}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#FF2B44] py-3 text-sm font-bold text-white transition hover:bg-[#e8243c]"
              >
                <Building2 size={16} />
                Create Organization
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ---- Create Organization section ----

  const orgTierLabels: Record<OrgTier, string> = {
    team: 'Team',
    club: 'Club',
    association: 'Association',
    federation: 'Federation',
  };

  return (
    <div className="fixed inset-0 z-[100]" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="absolute right-0 top-0 h-full w-[85%] max-w-sm overflow-y-auto border-l border-[#262A35] bg-[#12141A] scrollbar-none">
        <div className="sticky top-0 z-10 flex items-center gap-3 border-b border-[#262A35] bg-[#12141A] px-4 py-3.5">
          <button onClick={() => setSection('orgManagement')} className="text-[#9CA3AF] transition hover:text-[#F3F4F6]">
            <ArrowLeftRight size={16} className="rotate-180" />
          </button>
          <h3 className="text-sm font-black text-[#F3F4F6]">CREATE ORG</h3>
          <button onClick={onClose} className="ml-auto text-[#9CA3AF] transition hover:text-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        <div className="space-y-4 p-4">
          {/* Tier selector */}
          <div>
            <label className={labelClass}>Organization Tier</label>
            <div className="grid grid-cols-2 gap-1.5 rounded-xl border border-[#262A35] bg-[#0B0D10] p-1.5">
              {ORG_TIERS.map((tier) => (
                <button
                  key={tier.value}
                  onClick={() => setCreateTier(tier.value)}
                  className={`rounded-lg py-2 text-[11px] font-bold transition-all ${
                    createTier === tier.value
                      ? 'bg-[#FF2B44] text-white'
                      : 'text-[#9CA3AF] hover:text-[#F3F4F6]'
                  }`}
                >
                  {orgTierLabels[tier.value]}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className={labelClass}>
              {createTier === 'team' ? 'Team Name' : createTier === 'club' ? 'Club Name' : createTier === 'association' ? 'Association Name' : 'Federation Name'}
            </label>
            <input
              type="text"
              value={createName}
              onChange={(e) => setCreateName(e.target.value)}
              placeholder="Entity name"
              className={inputClass}
            />
          </div>

          <div>
            <label className={labelClass}>Contact Person</label>
            <input
              type="text"
              value={createContact}
              onChange={(e) => setCreateContact(e.target.value)}
              placeholder="Contact name"
              className={inputClass}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelClass}>Contact Phone</label>
              <div className="relative">
                <input
                  type="tel"
                  value={createPhone}
                  onChange={(e) => setCreatePhone(e.target.value)}
                  placeholder="+91..."
                  className={`${inputClass} pl-8`}
                />
                <Phone size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
              </div>
            </div>
            {createTier !== 'team' && (
              <div>
                <label className={labelClass}>Registration ID</label>
                <input
                  type="text"
                  value={createRegId}
                  onChange={(e) => setCreateRegId(e.target.value)}
                  placeholder="ID number"
                  className={inputClass}
                />
              </div>
            )}
          </div>

          <div>
            <label className={labelClass}>Address</label>
            <div className="relative">
              <input
                type="text"
                value={createAddress}
                onChange={(e) => setCreateAddress(e.target.value)}
                placeholder="Full address"
                className={`${inputClass} pl-8`}
              />
              <MapPin size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className={labelClass}>Country</label>
              <select value={createCountry} onChange={(e) => setCreateCountry(e.target.value)} className={inputClass}>
                {COUNTRIES.filter((c) => c !== 'World').map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className={labelClass}>State</label>
              <select value={createState} onChange={(e) => setCreateState(e.target.value)} className={inputClass}>
                {COUNTRY_STATES['India'].filter((s) => s !== 'All States').map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className={labelClass}>Region</label>
              <select value={createRegion} onChange={(e) => setCreateRegion(e.target.value)} className={inputClass}>
                {['North Bengal', ...DISTRICTS].map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>
          </div>

          {createTier !== 'team' && (
            <div>
              <label className={labelClass}>
                {createTier === 'club' ? 'AFFILIATION DOCUMENT' : 'AFFILIATION CERTIFICATE'}
              </label>
              <label className="block w-full">
                <input
                  type="file"
                  accept=".pdf,.jpg,.png,.doc,.docx"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) setCreateDocName(f.name);
                  }}
                />
                <div className="flex cursor-pointer items-center gap-2 rounded-xl border border-[#FF2B44]/30 bg-[#FF2B44]/10 px-3.5 py-2.5 text-xs font-bold text-[#FF2B44] transition hover:bg-[#FF2B44]/20">
                  <FileText size={14} />
                  Choose File
                </div>
              </label>
              {createDocName && (
                <p className="mt-1.5 flex items-center gap-1 text-[10px] text-[#10B981]">
                  <Check size={11} /> {createDocName}
                </p>
              )}
            </div>
          )}

          {orgError && (
            <div className="flex items-center gap-2 rounded-lg border border-[#FF2B44]/40 bg-[#FF2B44]/10 px-3 py-2 text-xs text-[#FF2B44]">
              <AlertCircle size={14} />
              {orgError}
            </div>
          )}

          <button
            onClick={handleCreateOrg}
            disabled={creatingOrg}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#FF2B44] py-3 text-sm font-bold text-white transition hover:bg-[#e8243c] disabled:opacity-60"
          >
            {creatingOrg ? <Loader2 size={16} className="animate-spin" /> : <Building2 size={16} />}
            {createTier === 'team' ? 'Create Team' : `Submit ${orgTierLabels[createTier]} for Review`}
          </button>
        </div>
      </div>
    </div>
  );
}
