import { useState } from 'react';
import { AuthProvider } from '@/context/AuthContext';
import TopBar, { type NavPill } from '@/components/TopBar';
import BottomNav, { type TabId } from '@/components/BottomNav';
import AuthModal from '@/components/AuthModal';
import FeedPage from '@/pages/FeedPage';
import RankingsPage from '@/pages/RankingsPage';
import CoachPage from '@/pages/CoachPage';
import MediaPage from '@/pages/MediaPage';
import ProfilePage from '@/pages/ProfilePage';

function AppContent() {
  const [activeTab, setActiveTab] = useState<TabId>('ranks');
  const [activePill, setActivePill] = useState<NavPill>('athletes');
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signup' | 'login'>('signup');

  const openAuth = (mode: 'signup' | 'login') => {
    setAuthMode(mode);
    setAuthOpen(true);
  };

  const requireAuth = () => openAuth('signup');

  return (
    <div className="min-h-screen select-none bg-[#0B0D10] pb-24 font-sans text-[#F3F4F6]">
      <TopBar
        onOpenAuth={openAuth}
        activePill={activePill}
        onPillChange={setActivePill}
      />

      <main className="mx-auto w-full max-w-lg flex-1 px-4 pt-6">
        {activeTab === 'feed' && <FeedPage onRequireAuth={requireAuth} />}
        {activeTab === 'ranks' && <RankingsPage />}
        {activeTab === 'coach' && <CoachPage />}
        {activeTab === 'media' && <MediaPage />}
        {activeTab === 'profile' && (
          <ProfilePage onRequireAuth={requireAuth} />
        )}
      </main>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      <AuthModal
        open={authOpen}
        initialMode={authMode}
        onClose={() => setAuthOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
