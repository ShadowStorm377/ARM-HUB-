/*
# Extend profiles and rankings for ARM HUB v3 auth flow

## Overview
Adds the fields needed for the new profile-based auth flow: handle, role,
weight_class, primary_arm, country, state, region on the profiles table.
Also extends the existing rankings table with points, elo, hand columns
and adds a foreign key from rankings.user_id to profiles.id with ON DELETE CASCADE.
Enables public read policies so unauthenticated visitors can browse
feed and rankings freely.

## Changes to existing tables

### profiles — added columns
- `handle` (text, nullable) — unique username/handle
- `role` (text, default 'athlete') — 'athlete', 'admin', 'coach'
- `weight_class` (text, nullable) — e.g. '70kg'
- `primary_arm` (text, default 'right') — 'left' or 'right'
- `country` (text, nullable) — e.g. 'India'
- `state` (text, nullable) — e.g. 'West Bengal'
- `region` (text, nullable) — e.g. 'North Bengal'

### rankings — added columns
- `points` (integer, default 0)
- `elo` (integer, default 1000)
- `hand` (text, default 'right') — 'left' or 'right'

## Foreign Keys
- rankings.user_id → profiles.id ON DELETE CASCADE (replaces existing FK to auth.users)

## Security
- profiles SELECT: TO anon, authenticated (public browsing)
- profiles INSERT: TO authenticated WITH CHECK (auth.uid() = id) — only on signup
- profiles UPDATE: TO authenticated WITH CHECK (auth.uid() = id) — only own profile
- rankings SELECT: TO anon, authenticated (public browsing)
- rankings INSERT/UPDATE/DELETE: TO authenticated, ownership-scoped

## Important Notes
1. No data is lost — all changes are additive (ALTER TABLE ADD COLUMN).
2. The existing handle_new_user trigger already creates a profile row on signup.
3. The old rankings FK to auth.users is replaced with a FK to profiles.id.
4. Public read access enables the "no sign-in wall" browsing experience.
*/

-- Add columns to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS handle text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'athlete';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS weight_class text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS primary_arm text NOT NULL DEFAULT 'right';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS country text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS state text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS region text;

-- Add a unique index on handle (partial — only where handle is not null)
DO $$ BEGIN
  CREATE UNIQUE INDEX IF NOT EXISTS profiles_handle_unique ON profiles (handle) WHERE handle IS NOT NULL;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Add columns to rankings
ALTER TABLE rankings ADD COLUMN IF NOT EXISTS points integer NOT NULL DEFAULT 0;
ALTER TABLE rankings ADD COLUMN IF NOT EXISTS elo integer NOT NULL DEFAULT 1000;
ALTER TABLE rankings ADD COLUMN IF NOT EXISTS hand text NOT NULL DEFAULT 'right';

-- Replace the rankings FK: drop old FK to auth.users, add FK to profiles.id
-- We do this carefully to avoid data loss. The old FK is named rankings_user_id_fkey.
ALTER TABLE rankings DROP CONSTRAINT IF EXISTS rankings_user_id_fkey;
ALTER TABLE rankings ADD CONSTRAINT rankings_user_id_profiles_fkey
  FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE;

-- Update profiles policies for public read + authenticated write
DROP POLICY IF EXISTS "select_profiles" ON profiles;
CREATE POLICY "select_profiles" ON profiles FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Update rankings policies for public read + authenticated write
DROP POLICY IF EXISTS "select_rankings" ON rankings;
CREATE POLICY "select_rankings" ON rankings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_rankings" ON rankings;
CREATE POLICY "insert_own_rankings" ON rankings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_rankings" ON rankings;
CREATE POLICY "update_own_rankings" ON rankings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_rankings" ON rankings;
CREATE POLICY "delete_own_rankings" ON rankings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Update the handle_new_user trigger to include new fields
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, handle, role, primary_arm)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Athlete'),
    COALESCE(NEW.raw_user_meta_data->>'handle', NULL),
    'athlete',
    COALESCE(NEW.raw_user_meta_data->>'primary_arm', 'right')
  );
  RETURN NEW;
END;
$$;

-- Indexes for new columns
CREATE INDEX IF NOT EXISTS idx_profiles_handle ON profiles (handle);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles (role);
CREATE INDEX IF NOT EXISTS idx_rankings_elo ON rankings (elo DESC);
CREATE INDEX IF NOT EXISTS idx_rankings_hand ON rankings (hand);
