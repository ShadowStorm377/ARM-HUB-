/*
# Allow unauthenticated browsing (no sign-in wall)

## Overview
Opens up read access so visitors can browse rankings, votes, and profiles
without being signed in. The app now opens directly to a dashboard showing
top rankings and the recent feed. Sign-in/sign-up buttons remain in the
header for when users want to create, vote, or edit their profile.

## Changes
1. rankings SELECT policy: now `TO anon, authenticated` (was `TO authenticated`)
2. votes SELECT policy: now `TO anon, authenticated` (was `TO authenticated`)
3. profiles SELECT policy: now `TO anon, authenticated` (was `TO authenticated`)

Write/delete policies remain `TO authenticated` with ownership checks —
only logged-in users can create rankings, vote, edit their profile, or delete
their own content.
*/

DROP POLICY IF EXISTS "select_rankings" ON rankings;
CREATE POLICY "select_rankings" ON rankings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "select_votes" ON votes;
CREATE POLICY "select_votes" ON votes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "select_profiles" ON profiles;
CREATE POLICY "select_profiles" ON profiles FOR SELECT
  TO anon, authenticated USING (true);
