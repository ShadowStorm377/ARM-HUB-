/*
# ARM HUB v10.2 — Organizations table + profile schema extensions

## Overview
Adds support for the multi-tier organization onboarding flow (Team, Club,
Association, Federation) and extends the profiles table with the fields
needed for athlete registration (handle, weight_class, age_group, country,
state, region already exist; we add username and org_link fields).

## New Tables

### organizations
- `id` (uuid, pk)
- `user_id` (uuid, default auth.uid, references auth.users) — the account that registered the org
- `tier` (text, not null) — 'team' | 'club' | 'association' | 'federation'
- `name` (text, not null) — entity name
- `contact_name` (text, nullable) — captain / head coach / president / secretary
- `contact_phone` (text, nullable)
- `email` (text, nullable) — official email
- `registration_id` (text, nullable) — affiliation / certificate number
- `address` (text, nullable)
- `city` (text, nullable)
- `country` (text, nullable, default 'India')
- `state` (text, nullable, default 'West Bengal')
- `region` (text, nullable, default 'North Bengal')
- `status` (text, not null, default 'approved') — 'approved' | 'under_review'
- `doc_file_name` (text, nullable) — name of uploaded doc (metadata only, file stays local)
- `created_at` (timestamptz, default now())

## Changes to existing tables

### profiles — added columns
- `username` (text, nullable) — the @handle chosen at registration
- `organization_id` (uuid, nullable, references organizations) — links an athlete to their team/club

## Security
- organizations: SELECT public (anon+authenticated), INSERT/UPDATE/DELETE owner-scoped (authenticated, auth.uid = user_id).
- profiles: existing policies extended to cover new columns automatically (column-level RLS not in use).

## Important Notes
1. No data is lost — all changes are additive.
2. The `status` column defaults to 'approved' for teams (instant activation) and is set to 'under_review' by the frontend for club/association/federation tiers.
3. File uploads for affiliation documents are stored as filename metadata only — actual files stay on-device per the zero-cloud principle.
*/

-- Organizations table
CREATE TABLE IF NOT EXISTS organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  tier text NOT NULL CHECK (tier IN ('team', 'club', 'association', 'federation')),
  name text NOT NULL,
  contact_name text,
  contact_phone text,
  email text,
  registration_id text,
  address text,
  city text,
  country text DEFAULT 'India',
  state text DEFAULT 'West Bengal',
  region text DEFAULT 'North Bengal',
  status text NOT NULL DEFAULT 'approved' CHECK (status IN ('approved', 'under_review')),
  doc_file_name text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_organizations" ON organizations;
CREATE POLICY "select_organizations" ON organizations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_organizations" ON organizations;
CREATE POLICY "insert_own_organizations" ON organizations FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_organizations" ON organizations;
CREATE POLICY "update_own_organizations" ON organizations FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_organizations" ON organizations;
CREATE POLICY "delete_own_organizations" ON organizations FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Add columns to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS username text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS organization_id uuid REFERENCES organizations(id) ON DELETE SET NULL;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_organizations_tier ON organizations (tier);
CREATE INDEX IF NOT EXISTS idx_organizations_user ON organizations (user_id);
CREATE INDEX IF NOT EXISTS idx_profiles_username ON profiles (username);
CREATE INDEX IF NOT EXISTS idx_profiles_organization ON profiles (organization_id);
