/*
# Extend schema for ARM HUB v2: hands, match records, feed posts, media

## Overview
Adds hand (left/right) to players and lift_records, match win/loss tracking,
association feed posts, and media items (live streams, reels, full videos).

## Changes to existing tables

### players — added columns
- `hand` (text, default 'right') — 'left' or 'right'
- `wins` (integer, default 0)
- `losses` (integer, default 0)
- `state` (text, nullable) — e.g. "West Bengal"
- `region` already exists

### lift_records — added column
- `hand` (text, default 'right') — 'left' or 'right'

## New Tables

### feed_posts
- `id` (uuid, pk)
- `title` (text, not null)
- `body` (text, nullable)
- `author_name` (text, not null) — poster name
- `user_id` (uuid, default auth.uid, references auth.users)
- `created_at` (timestamptz, default now())

### media_items
- `id` (uuid, pk)
- `title` (text, not null)
- `media_type` (text, not null) — 'live', 'reel', or 'full'
- `url` (text, nullable) — external link
- `thumbnail_url` (text, nullable)
- `user_id` (uuid, default auth.uid, references auth.users)
- `created_at` (timestamptz, default now())

## Security
- feed_posts & media_items: anon+authenticated can read; authenticated can insert their own.
- No destructive changes to existing data.
*/

-- Add columns to players
ALTER TABLE players ADD COLUMN IF NOT EXISTS hand text NOT NULL DEFAULT 'right';
ALTER TABLE players ADD COLUMN IF NOT EXISTS wins integer NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS losses integer NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS state text;

-- Add column to lift_records
ALTER TABLE lift_records ADD COLUMN IF NOT EXISTS hand text NOT NULL DEFAULT 'right';

-- Feed posts table
CREATE TABLE IF NOT EXISTS feed_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text,
  author_name text NOT NULL,
  user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE feed_posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_feed_posts" ON feed_posts;
CREATE POLICY "select_feed_posts" ON feed_posts FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_feed_posts" ON feed_posts;
CREATE POLICY "insert_own_feed_posts" ON feed_posts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_feed_posts" ON feed_posts;
CREATE POLICY "delete_own_feed_posts" ON feed_posts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Media items table
CREATE TABLE IF NOT EXISTS media_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  media_type text NOT NULL CHECK (media_type IN ('live', 'reel', 'full')),
  url text,
  thumbnail_url text,
  user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE media_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_media_items" ON media_items;
CREATE POLICY "select_media_items" ON media_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_media_items" ON media_items;
CREATE POLICY "insert_own_media_items" ON media_items FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_media_items" ON media_items;
CREATE POLICY "delete_own_media_items" ON media_items FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_feed_posts_created ON feed_posts (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_media_items_type ON media_items (media_type);
CREATE INDEX IF NOT EXISTS idx_players_hand ON players (hand);
