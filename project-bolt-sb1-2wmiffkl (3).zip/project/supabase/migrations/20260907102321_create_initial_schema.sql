/*
# Create initial schema for RankIt community platform

## Overview
Creates the database schema for a community ranking platform where users
create ranked lists, vote on them, and browse a feed of recent rankings.
Includes user profiles with full name and age group.

## New Tables

### profiles
- `id` (uuid, primary key, references auth.users) — one row per user
- `full_name` (text, not null) — display name shown across the app
- `age_group` (text, not null) — age category: under_18, 18_24, 25_34, 35_44, 45_54, 55_plus
- `bio` (text, nullable) — optional short bio
- `created_at` (timestamptz, defaults to now)

### rankings
- `id` (uuid, primary key)
- `title` (text, not null)
- `description` (text, nullable)
- `category` (text, not null) — e.g. Movies, Games, Music, Food, Sports, Tech
- `user_id` (uuid, not null, defaults to auth.uid, references auth.users)
- `created_at` (timestamptz, defaults to now)

### votes
- `id` (uuid, primary key)
- `ranking_id` (uuid, not null, references rankings, cascade delete)
- `user_id` (uuid, not null, defaults to auth.uid, references auth.users)
- `created_at` (timestamptz, defaults to now)
- Unique constraint on (ranking_id, user_id) — one vote per user per ranking

## Security
- RLS enabled on all tables.
- profiles: authenticated users can read all profiles; users can only update their own.
- rankings: all authenticated users can read; users can only insert/update/delete their own.
- votes: all authenticated users can read; users can only insert/delete their own votes.

## Important Notes
1. `user_id` columns default to `auth.uid()` so client inserts that omit user_id still pass RLS.
2. A trigger auto-creates a profile row when a new auth user signs up.
3. All policies scoped to `authenticated` since this app requires sign-in.
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  age_group text NOT NULL CHECK (
    age_group IN ('under_18', '18_24', '25_34', '35_44', '45_54', '55_plus')
  ),
  bio text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_profiles" ON profiles;
CREATE POLICY "select_profiles" ON profiles FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Rankings table
CREATE TABLE IF NOT EXISTS rankings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  category text NOT NULL DEFAULT 'General',
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE rankings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_rankings" ON rankings;
CREATE POLICY "select_rankings" ON rankings FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_rankings" ON rankings;
CREATE POLICY "insert_own_rankings" ON rankings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_rankings" ON rankings;
CREATE POLICY "update_own_rankings" ON rankings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_rankings" ON rankings;
CREATE POLICY "delete_own_rankings" ON rankings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Votes table
CREATE TABLE IF NOT EXISTS votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ranking_id uuid NOT NULL REFERENCES rankings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE (ranking_id, user_id)
);

ALTER TABLE votes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_votes" ON votes;
CREATE POLICY "select_votes" ON votes FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_votes" ON votes;
CREATE POLICY "insert_own_votes" ON votes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_votes" ON votes;
CREATE POLICY "delete_own_votes" ON votes FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, age_group)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Anonymous'),
    COALESCE(NEW.raw_user_meta_data->>'age_group', '25_34')
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_rankings_created_at ON rankings (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_rankings_user_id ON rankings (user_id);
CREATE INDEX IF NOT EXISTS idx_votes_ranking_id ON votes (ranking_id);
CREATE INDEX IF NOT EXISTS idx_votes_user_id ON votes (user_id);