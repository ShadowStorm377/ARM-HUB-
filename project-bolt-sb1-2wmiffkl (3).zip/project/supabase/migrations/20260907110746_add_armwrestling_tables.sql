/*
# Add armwrestling tables: players, clubs, associations, lift_records

## Overview
Extends the RankIt schema into ARM HUB — an armwrestling platform.
Adds tables for player registrations, club registrations, association
registrations, and verified lift records (max lifts per weight class and lift type).

## New Tables

### players
- `id` (uuid, primary key)
- `user_id` (uuid, nullable, references auth.users — linked to the account that registered)
- `full_name` (text, not null)
- `weight_class` (text, not null) — one of the defined weight classes
- `club_name` (text, nullable) — club affiliation
- `region` (text, nullable) — geographic region
- `elo_rating` (integer, default 1000) — competitive rating
- `created_at` (timestamptz, default now())

### clubs
- `id` (uuid, primary key)
- `name` (text, not null)
- `head_coach` (text, nullable)
- `region` (text, nullable)
- `created_at` (timestamptz, default now())

### associations
- `id` (uuid, primary key)
- `name` (text, not null)
- `registration_id` (text, nullable) — official registration/tax ID
- `created_at` (timestamptz, default now())

### lift_records
- `id` (uuid, primary key)
- `player_id` (uuid, references players, cascade delete)
- `player_name` (text, not null) — denormalized for fast display
- `weight_class` (text, not null)
- `lift_type` (text, not null) — Pronation Hold, Rising Max, Cupping/Wrist Curl, Rolling Thunder
- `weight_kg` (numeric, not null) — the lift weight
- `verified` (boolean, default false) — AI verification status
- `user_id` (uuid, default auth.uid, references auth.users)
- `created_at` (timestamptz, default now())

## Security
- RLS enabled on all new tables.
- players/clubs/associations/lift_records SELECT: `TO anon, authenticated` — visitors can browse.
- INSERT/UPDATE/DELETE: `TO authenticated` with ownership check on `user_id`.
- players has `user_id` defaulting to `auth.uid()` so inserts without user_id pass RLS.
*/

-- Players table
CREATE TABLE IF NOT EXISTS players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name text NOT NULL,
  weight_class text NOT NULL,
  club_name text,
  region text,
  elo_rating integer NOT NULL DEFAULT 1000,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE players ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_players" ON players;
CREATE POLICY "select_players" ON players FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_players" ON players;
CREATE POLICY "insert_own_players" ON players FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_players" ON players;
CREATE POLICY "update_own_players" ON players FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_players" ON players;
CREATE POLICY "delete_own_players" ON players FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Clubs table
CREATE TABLE IF NOT EXISTS clubs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  head_coach text,
  region text,
  user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE clubs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_clubs" ON clubs;
CREATE POLICY "select_clubs" ON clubs FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_clubs" ON clubs;
CREATE POLICY "insert_own_clubs" ON clubs FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_clubs" ON clubs;
CREATE POLICY "update_own_clubs" ON clubs FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_clubs" ON clubs;
CREATE POLICY "delete_own_clubs" ON clubs FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Associations table
CREATE TABLE IF NOT EXISTS associations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  registration_id text,
  user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE associations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_associations" ON associations;
CREATE POLICY "select_associations" ON associations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_associations" ON associations;
CREATE POLICY "insert_own_associations" ON associations FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_associations" ON associations;
CREATE POLICY "update_own_associations" ON associations FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_associations" ON associations;
CREATE POLICY "delete_own_associations" ON associations FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Lift records table
CREATE TABLE IF NOT EXISTS lift_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id uuid REFERENCES players(id) ON DELETE CASCADE,
  player_name text NOT NULL,
  weight_class text NOT NULL,
  lift_type text NOT NULL,
  weight_kg numeric NOT NULL,
  verified boolean NOT NULL DEFAULT false,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE lift_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_lift_records" ON lift_records;
CREATE POLICY "select_lift_records" ON lift_records FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_lift_records" ON lift_records;
CREATE POLICY "insert_own_lift_records" ON lift_records FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_lift_records" ON lift_records;
CREATE POLICY "update_own_lift_records" ON lift_records FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_lift_records" ON lift_records;
CREATE POLICY "delete_own_lift_records" ON lift_records FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_players_weight_class ON players (weight_class);
CREATE INDEX IF NOT EXISTS idx_players_elo ON players (elo_rating DESC);
CREATE INDEX IF NOT EXISTS idx_lift_records_weight_class ON lift_records (weight_class);
CREATE INDEX IF NOT EXISTS idx_lift_records_lift_type ON lift_records (lift_type);
CREATE INDEX IF NOT EXISTS idx_clubs_region ON clubs (region);
